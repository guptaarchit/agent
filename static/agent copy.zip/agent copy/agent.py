"""Agent core — agentic loop with mode routing, approval gates, guardrails, and streaming."""

from __future__ import annotations

import asyncio
import json
import logging
import re as re_mod
import time
from typing import Any, AsyncGenerator

import config
import context_manager
import llm_client
import memory
import router
import session_state
import session_store
import shadow_store
import approval_store
import file_store
from guardrails import (
    audit_logger,
    cost_tracker,
    input_validator,
    output_filter,
    tool_policy,
)
from guardrails.audit_logger import AuditEventType
from mcp_client import mcp_client
from middleware.circuit_breaker import mcp_circuit_breaker
from models.events import (
    ApprovalRequiredEvent,
    DataChunkEvent,
    DoneEvent,
    ErrorEvent,
    FileAvailableEvent,
    PlanEvent,
    SessionCreatedEvent,
    SSEEvent,
    TextDeltaEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from models.common import ExecutionMode, Plan, PlanStep, TokenUsage

logger = logging.getLogger(__name__)

# Keep references to fire-and-forget tasks to prevent GC
_background_tasks: set[asyncio.Task] = set()


def _fire_and_forget(coro) -> None:
    """Schedule a coroutine as a background task, preventing premature GC."""
    task = asyncio.create_task(coro)
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)


# ═══════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════


async def run_chat(
    session_id: str | None,
    message: str,
    mode: ExecutionMode,
    user_id: str,
    correlation_id: str,
    bearer_token: str | None = None,
) -> AsyncGenerator[SSEEvent, None]:
    """Main entry point. Yields SSE events as the agent processes the request."""

    # ── INPUT VALIDATION ────────────────────────────────────────────
    validation = input_validator.validate_message(message)
    if validation.blocked:
        yield ErrorEvent(message=validation.block_reason, recoverable=False)
        return

    if validation.warnings:
        audit_logger.log_event(
            AuditEventType.INJECTION_DETECTED,
            session_id=session_id or "",
            user_id=user_id,
            correlation_id=correlation_id,
            data={"warnings": validation.warnings, "message_preview": message[:200]},
        )

    # ── COST CHECK ──────────────────────────────────────────────────
    if session_id:
        allowed, reason, _ = await cost_tracker.check_budget(session_id, user_id)
        if not allowed:
            yield ErrorEvent(message=reason, recoverable=False)
            return

    # ── SESSION ─────────────────────────────────────────────────────
    if not session_id:
        session_data = await session_store.create_session(mode=mode)
        session_id = session_data["session_id"]
        yield SessionCreatedEvent(session_id=session_id)
        audit_logger.log_event(
            AuditEventType.SESSION_CREATED,
            session_id=session_id,
            user_id=user_id,
            correlation_id=correlation_id,
        )
    else:
        session_data = await session_store.get_session(session_id)
        if not session_data:
            yield ErrorEvent(message="Session not found or expired", recoverable=False)
            return

    # Append user message
    await session_store.append_message(session_id, {"role": "user", "content": message})

    # Async: store in Pinecone for long-term memory
    messages = await session_store.get_messages(session_id)
    _fire_and_forget(
        memory.store_message(session_id, len(messages) - 1, "user", message)
    )

    audit_logger.log_event(
        AuditEventType.MESSAGE_RECEIVED,
        session_id=session_id,
        user_id=user_id,
        correlation_id=correlation_id,
        data={"message_preview": message[:200], "mode": mode},
    )

    # ── TOOLS + ROUTING ─────────────────────────────────────────────
    # Agent always gets ALL MCP meta-tools (list_internal_tools, get_tool_schema, run_internal_tool)
    # Routing only affects the system prompt hint — telling the agent which area to focus on
    tools = mcp_client.get_tools()
    tools = tool_policy.filter_tools(tools)

    # Route to determine focus area (fast keyword match, no LLM call)
    tool_groups = router.classify_tools_to_groups(tools)
    state = await session_state.get_state(session_id)
    group_name = await router.route_request(
        message, tool_groups, current_group=state.get("active_group"),
    )
    logger.info("Focus area: '%s'", group_name)
    await session_state.update_state(session_id, active_group=group_name)

    # ── MODE ROUTER ─────────────────────────────────────────────────
    if mode == ExecutionMode.PLAN:
        async for event in _run_plan_mode(session_id, tools, user_id, correlation_id):
            yield event
    else:
        async for event in _run_auto_mode(session_id, tools, user_id, correlation_id, bearer_token):
            yield event


# ═══════════════════════════════════════════════════════════════════════
# PLAN MODE
# ═══════════════════════════════════════════════════════════════════════


async def _run_plan_mode(
    session_id: str,
    tools: list[dict[str, Any]],
    user_id: str,
    correlation_id: str,
) -> AsyncGenerator[SSEEvent, None]:
    """Generate a structured execution plan without calling any tools."""
    yield ThinkingEvent(message="Generating execution plan...")

    messages = await session_store.get_messages(session_id)
    prepared = await context_manager.prepare_context(
        messages, config.SYSTEM_PROMPT_PLAN, tools, session_id
    )

    response = await llm_client.chat_complete(
        messages=[{"role": "system", "content": config.SYSTEM_PROMPT_PLAN}] + prepared,
        tools=tools,
    )

    content = response.get("content", "")
    plan_event = _parse_plan(content, session_id, messages)
    if plan_event:
        yield plan_event
    else:
        yield TextDeltaEvent(delta=content)

    await session_store.append_message(session_id, {"role": "assistant", "content": content})
    audit_logger.log_event(
        AuditEventType.PLAN_GENERATED, session_id=session_id,
        user_id=user_id, correlation_id=correlation_id,
    )
    yield DoneEvent(summary="Plan generated — awaiting approval")


async def _parse_plan(content: str, session_id: str, messages: list) -> PlanEvent | None:
    """Try to parse a structured plan from LLM response."""
    try:
        json_match = re_mod.search(r"\{.*\}", content, re_mod.DOTALL)
        raw = json_match.group() if json_match else content
        plan_data = json.loads(raw)

        steps = [
            PlanStep(
                step=s.get("step", i + 1), tool=s.get("tool", ""),
                arguments=s.get("arguments", {}), type=s.get("type", "read"),
                description=s.get("description", ""),
            )
            for i, s in enumerate(plan_data.get("steps", []))
        ]

        plan_id = await approval_store.create_pending_plan(
            session_id=session_id,
            steps=[s.model_dump() for s in steps],
            summary=plan_data.get("summary", ""),
            agent_state={"messages_count": len(messages)},
        )

        return PlanEvent(plan=Plan(
            plan_id=plan_id,
            summary=plan_data.get("summary", "Plan generated"),
            steps=steps,
        ))
    except (json.JSONDecodeError, KeyError):
        return None


# ═══════════════════════════════════════════════════════════════════════
# AUTO MODE (main agentic loop)
# ═══════════════════════════════════════════════════════════════════════


async def _run_auto_mode(
    session_id: str,
    tools: list[dict[str, Any]],
    user_id: str,
    correlation_id: str,
    bearer_token: str | None = None,
) -> AsyncGenerator[SSEEvent, None]:
    """Run the iterative agent loop: call LLM, execute tools, repeat until done."""
    yield ThinkingEvent(message="Processing your request...")

    session = await session_store.get_session(session_id)
    tool_call_count = session.get("tool_call_count", 0) if session else 0
    destructive_count = session.get("destructive_action_count", 0) if session else 0
    tools_used: list[str] = []
    total_usage = TokenUsage()

    for iteration in range(config.MAX_ITERATIONS):
        # Cost check
        allowed, reason, _ = await cost_tracker.check_budget(session_id, user_id)
        if not allowed:
            yield ErrorEvent(message=reason, recoverable=False)
            break

        # Prepare context with session state
        current_messages = await session_store.get_messages(session_id)
        prepared = await context_manager.prepare_context(
            current_messages, config.SYSTEM_PROMPT_AUTO, tools, session_id
        )
        # Build system prompt with user identity and session state
        state = await session_state.get_state(session_id)
        state_block = session_state.format_state_for_llm(state)
        focus_area = state.get("active_group", "general")
        system_prompt = (
            config.SYSTEM_PROMPT_AUTO
            + f"\nCurrent user: {user_id} (use as LDAP/username when tools require it)"
            + f"\nFocus area: {focus_area}."
            + (f"\n{state_block}" if state_block else "")
        )
        llm_messages = [{"role": "system", "content": system_prompt}] + prepared

        # Checkpoint
        await session_store.save_loop_state(session_id, {
            "iteration": iteration, "status": "running", "pending_tools": [],
        })

        # LLM call
        llm_result = await _stream_llm_call(llm_messages, tools)
        if llm_result is None:
            break  # LLM error already yielded inside _stream_llm_call

        text_buffer, tool_calls, stop_reason, usage = llm_result["text"], llm_result["tool_calls"], llm_result["stop_reason"], llm_result["usage"]

        # Yield streamed text
        for event in llm_result["events"]:
            yield event

        # Track usage
        _accumulate_usage(total_usage, usage)
        await cost_tracker.track_usage(session_id, user_id, usage.get("input_tokens", 0), usage.get("output_tokens", 0), config.DEFAULT_MODEL)
        audit_logger.log_event(
            AuditEventType.LLM_CALL, session_id=session_id, user_id=user_id,
            correlation_id=correlation_id,
            data={"iteration": iteration, "stop_reason": stop_reason, "usage": usage},
        )

        # Store assistant message
        await _store_assistant_message(session_id, text_buffer, tool_calls)

        # No tool calls → done
        # Check actual tool_calls list, not just stop_reason
        # (Azure OpenAI returns "tool_calls", Anthropic returns "tool_use", LiteLLM may vary)
        if not tool_calls:
            async for event in _finalize_turn(session_id, text_buffer, tools_used, total_usage, current_messages):
                yield event
            return

        # Execute tool calls
        exec_result = await _execute_tool_calls(
            session_id, tool_calls, tools_used, tool_call_count, destructive_count,
            user_id, correlation_id, iteration, bearer_token,
        )
        for event in exec_result["events"]:
            yield event

        if exec_result["paused"]:
            return  # waiting for approval
        if exec_result["limit_hit"]:
            yield DoneEvent(summary=exec_result["limit_reason"], tools_used=tools_used, token_usage=total_usage)
            return

        tool_call_count = exec_result["tool_call_count"]

        # Append tool results to history
        for tr in exec_result["tool_results"]:
            await session_store.append_message(session_id, tr)

    # Max iterations
    await session_store.delete_loop_state(session_id)
    yield ErrorEvent(message="Max iterations reached", recoverable=True)
    yield DoneEvent(
        summary="Agent reached maximum iterations. Please refine your request.",
        tools_used=tools_used, token_usage=total_usage,
    )


# ═══════════════════════════════════════════════════════════════════════
# AUTO MODE — sub-functions
# ═══════════════════════════════════════════════════════════════════════


async def _stream_llm_call(
    llm_messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Stream LLM call, collect text/tool_calls. Returns dict or None on error."""
    text_buffer = ""
    tool_calls: list[dict[str, Any]] = []
    stop_reason = "end_turn"
    usage: dict[str, int] = {}
    events: list[SSEEvent] = []

    try:
        async for chunk in llm_client.chat_stream(llm_messages, tools):
            if chunk["type"] == "text_delta":
                delta = output_filter.redact_secrets(chunk["delta"])
                text_buffer += delta
                events.append(TextDeltaEvent(delta=delta))
            elif chunk["type"] == "tool_call":
                tool_calls.append(chunk)
            elif chunk["type"] == "done":
                stop_reason = chunk.get("stop_reason", "end_turn")
                usage = chunk.get("usage", {})
    except Exception as e:
        logger.error("LLM call failed: %s", e, exc_info=True)
        events.append(ErrorEvent(message=f"LLM call failed: {e}", recoverable=True))
        return None

    return {"text": text_buffer, "tool_calls": tool_calls, "stop_reason": stop_reason, "usage": usage, "events": events}


async def _store_assistant_message(
    session_id: str, text_buffer: str, tool_calls: list[dict[str, Any]]
) -> None:
    """Persist the assistant's text and/or tool calls to session history."""
    if tool_calls:
        msg: dict[str, Any] = {"role": "assistant", "content": text_buffer or None}
        msg["tool_calls"] = [
            {"id": tc["id"], "type": "function", "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}}
            for tc in tool_calls
        ]
        await session_store.append_message(session_id, msg)
    elif text_buffer:
        await session_store.append_message(session_id, {"role": "assistant", "content": text_buffer})


async def _finalize_turn(
    session_id: str, text_buffer: str, tools_used: list[str],
    total_usage: TokenUsage, current_messages: list[dict[str, Any]],
) -> AsyncGenerator[SSEEvent, None]:
    """Emit hallucination warnings, store to memory, and yield the DoneEvent."""
    warnings = output_filter.check_hallucination(text_buffer, tools_used)
    for w in warnings:
        yield ErrorEvent(message=f"Warning: {w}", recoverable=True)

    if text_buffer:
        _fire_and_forget(
            memory.store_message(session_id, len(current_messages), "assistant", text_buffer)
        )

    await session_store.delete_loop_state(session_id)
    yield DoneEvent(summary=text_buffer[:200], tools_used=tools_used, token_usage=total_usage)


async def _execute_tool_calls(
    session_id: str,
    tool_calls: list[dict[str, Any]],
    tools_used: list[str],
    tool_call_count: int,
    destructive_count: int,
    user_id: str,
    correlation_id: str,
    iteration: int,
    bearer_token: str | None = None,
) -> dict[str, Any]:
    """Execute all tool calls from one LLM turn. Returns result dict."""
    events: list[SSEEvent] = []
    tool_results: list[dict[str, Any]] = []
    paused = False
    limit_hit = False
    limit_reason = ""

    for tc in tool_calls:
        tool_name, tool_args, tool_id = tc["name"], tc["arguments"], tc["id"]

        # Allowlist check
        if not tool_policy.is_tool_allowed(tool_name):
            audit_logger.log_event(
                AuditEventType.TOOL_BLOCKED, session_id=session_id,
                user_id=user_id, correlation_id=correlation_id,
                data={"tool": tool_name, "reason": "not in allowlist"},
            )
            tool_results.append({"role": "tool", "tool_call_id": tool_id, "content": f"Error: Tool '{tool_name}' is not allowed by policy."})
            continue

        # Argument validation
        valid, err_msg = tool_policy.validate_arguments(tool_name, tool_args, _get_tool_schema(tool_name))
        if not valid:
            tool_results.append({"role": "tool", "tool_call_id": tool_id, "content": f"Error: {err_msg}"})
            continue

        # Scope
        tool_args = tool_policy.apply_scope(tool_args)

        # Execution limits
        is_destr = tool_policy.is_destructive(tool_name)
        limit_ok, lr = await tool_policy.check_limits(session_id, tool_call_count, destructive_count, is_destr)
        if not limit_ok:
            events.append(ErrorEvent(message=lr, recoverable=False))
            audit_logger.log_event(AuditEventType.EXECUTION_LIMIT, session_id=session_id, user_id=user_id, correlation_id=correlation_id, data={"reason": lr})
            await session_store.delete_loop_state(session_id)
            limit_hit = True
            limit_reason = lr
            break

        # Destructive → pause for approval
        if is_destr:
            events.append(ToolCallEvent(tool=tool_name, arguments=tool_args))
            action_id = await approval_store.create_pending_action(
                session_id=session_id, tool=tool_name, arguments=tool_args,
                description=f"Execute destructive action: {tool_name}({json.dumps(tool_args)[:200]})",
                agent_state={"iteration": iteration, "remaining_tool_calls": [
                    {"id": t["id"], "name": t["name"], "arguments": t["arguments"]}
                    for t in tool_calls if t["id"] != tool_id
                ]},
            )
            audit_logger.log_event(AuditEventType.APPROVAL_REQUESTED, session_id=session_id, user_id=user_id, correlation_id=correlation_id, data={"action_id": action_id, "tool": tool_name})
            events.append(ApprovalRequiredEvent(action_id=action_id, tool=tool_name, arguments=tool_args, description=f"Destructive action: {tool_name}"))
            paused = True
            break

        # Safe tool → execute via MCP with user's Bearer token
        events.append(ToolCallEvent(tool=tool_name, arguments=tool_args))

        if not mcp_circuit_breaker.allow_request():
            tool_results.append({"role": "tool", "tool_call_id": tool_id, "content": "Error: MCP server temporarily unavailable (circuit breaker open)."})
            events.append(ToolResultEvent(tool=tool_name, result="MCP unavailable", is_error=True))
            continue

        call_events, result_entry = await _call_mcp_tool(session_id, tool_name, tool_args, tool_id, user_id, correlation_id, bearer_token)
        events.extend(call_events)
        tool_results.append(result_entry)

        if not result_entry["content"].startswith("Error:"):
            tools_used.append(tool_name)
            tool_call_count += 1
            await session_store.increment_tool_calls(session_id)

    return {
        "events": events, "tool_results": tool_results, "paused": paused,
        "limit_hit": limit_hit, "limit_reason": limit_reason, "tool_call_count": tool_call_count,
    }


async def _call_mcp_tool(
    session_id: str, tool_name: str, tool_args: dict[str, Any],
    tool_id: str, user_id: str, correlation_id: str,
    bearer_token: str | None = None,
) -> tuple[list[SSEEvent], dict[str, Any]]:
    """Execute a single MCP tool call.

    Returns (list of SSE events, tool result entry for LLM history).
    For large results: streams DataChunkEvents to UI, gives LLM a compact summary.
    """
    sse_events: list[SSEEvent] = []
    start_time = time.time()
    try:
        result = await mcp_client.call_tool(tool_name, tool_args, bearer_token=bearer_token)
        mcp_circuit_breaker.record_success()
        duration_ms = int((time.time() - start_time) * 1000)

        result_text = _extract_tool_result_text(result, tool_name)
        result_text = input_validator.sanitise_tool_result(result_text)
        is_error = result.get("is_error", False)

        # Try to parse as structured data
        try:
            parsed_data = json.loads(result_text)
        except (ValueError, TypeError):
            parsed_data = None

        # If structured list data → use shadow store + alias indexing
        if not is_error and isinstance(parsed_data, list) and parsed_data and isinstance(parsed_data[0], dict):
            # Store in shadow store with aliases
            store_result = await shadow_store.store_result(session_id, tool_name, parsed_data)

            # Chunk full data for UI
            chunks = output_filter.chunk_result(result_text)
            for chunk in chunks:
                sse_events.append(DataChunkEvent(
                    tool=tool_name,
                    chunk_index=chunk["chunk_index"],
                    total_chunks=chunk["total_chunks"],
                    data=chunk["data"],
                ))

            # LLM gets alias-indexed summary
            llm_text = shadow_store.build_llm_summary(store_result)

            # Update session state
            await session_state.update_state(
                session_id,
                last_tool=tool_name,
                last_resource_type=shadow_store._detect_resource_type(tool_name),
            )

        elif not is_error and parsed_data is not None:
            # Structured but not a list — chunk for UI, summarise for LLM
            chunks = output_filter.chunk_result(result_text)
            for chunk in chunks:
                sse_events.append(DataChunkEvent(
                    tool=tool_name,
                    chunk_index=chunk["chunk_index"],
                    total_chunks=chunk["total_chunks"],
                    data=chunk["data"],
                ))
            llm_text = output_filter.truncate_tool_result(result_text)

        else:
            # Plain text or error — pass through
            llm_text = output_filter.truncate_tool_result(result_text)

        audit_logger.log_event(
            AuditEventType.TOOL_EXECUTED, session_id=session_id, user_id=user_id,
            correlation_id=correlation_id,
            data={"tool": tool_name, "duration_ms": duration_ms, "is_error": is_error,
                  "result_chars": len(result_text), "items": len(parsed_data) if isinstance(parsed_data, list) else 0},
        )

        _fire_and_forget(memory.store_message(session_id, 0, "tool_result", result_text[:2000], tool_name=tool_name))

        sse_events.append(ToolResultEvent(
            tool=tool_name, result=llm_text[:500], is_error=is_error, duration_ms=duration_ms,
        ))

        return (
            sse_events,
            {"role": "tool", "tool_call_id": tool_id, "content": llm_text},
        )

    except asyncio.TimeoutError:
        mcp_circuit_breaker.record_failure()
        return (
            [ToolResultEvent(tool=tool_name, result="Timeout", is_error=True)],
            {"role": "tool", "tool_call_id": tool_id, "content": f"Error: Tool call timed out after {config.MCP_CALL_TIMEOUT}s"},
        )
    except Exception as e:
        mcp_circuit_breaker.record_failure()
        logger.error("MCP tool call failed: %s", e, exc_info=True)
        return (
            [ToolResultEvent(tool=tool_name, result=str(e)[:200], is_error=True)],
            {"role": "tool", "tool_call_id": tool_id, "content": f"Error: {e}"},
        )


def _extract_tool_result_text(result: dict[str, Any], tool_name: str) -> str:
    """Extract text content from MCP tool result, handling files."""
    text_parts: list[str] = []
    for part in result.get("content", []):
        if part.get("type") == "text":
            text_parts.append(part.get("text", ""))
        elif part.get("type") == "binary":
            text_parts.append(f"[File generated by {tool_name}]")
    return "".join(text_parts)


# ═══════════════════════════════════════════════════════════════════════
# RESUME AFTER APPROVAL / DENIAL
# ═══════════════════════════════════════════════════════════════════════


async def resume_after_approval(
    session_id: str,
    action_id: str,
    user_id: str,
    correlation_id: str,
    bearer_token: str | None = None,
) -> AsyncGenerator[SSEEvent, None]:
    """Execute an approved destructive action and resume the loop."""
    pending = await approval_store.approve(session_id, action_id)
    if not pending:
        yield ErrorEvent(message="Action not found or expired", recoverable=False)
        return

    status = pending.get("status", "")
    if status == "completed":
        yield DoneEvent(summary="Action already completed")
        return
    if status == "denied":
        yield ErrorEvent(message="Action was denied", recoverable=False)
        return

    tool_name = pending.get("tool", "")
    tool_args = pending.get("arguments", {})
    if isinstance(tool_args, str):
        tool_args = json.loads(tool_args)

    yield ToolCallEvent(tool=tool_name, arguments=tool_args)

    start_time = time.time()
    try:
        result = await mcp_client.call_tool(tool_name, tool_args, bearer_token=bearer_token)
        duration_ms = int((time.time() - start_time) * 1000)

        result_text = _extract_tool_result_text(result, tool_name)
        result_text = output_filter.redact_secrets(result_text)
        yield ToolResultEvent(tool=tool_name, result=result_text[:500], duration_ms=duration_ms)

        await approval_store.mark_completed(session_id, action_id, result_text)
        await session_store.append_message(session_id, {
            "role": "tool", "tool_call_id": f"approved_{action_id}", "content": result_text,
        })
        await session_store.increment_tool_calls(session_id)
        await session_store.increment_destructive_actions(session_id)

        audit_logger.log_event(
            AuditEventType.APPROVAL_GRANTED, session_id=session_id,
            user_id=user_id, correlation_id=correlation_id,
            data={"action_id": action_id, "tool": tool_name, "duration_ms": duration_ms},
        )

        # Continue loop
        tools = tool_policy.filter_tools(mcp_client.get_tools())
        async for event in _run_auto_mode(session_id, tools, user_id, correlation_id, bearer_token):
            yield event

    except Exception as e:
        logger.error("Approved tool execution failed: %s", e, exc_info=True)
        yield ErrorEvent(message=f"Tool execution failed: {e}", recoverable=True)
        await approval_store.mark_completed(session_id, action_id, f"Error: {e}")


async def resume_after_denial(
    session_id: str,
    action_id: str,
    reason: str,
    user_id: str,
    correlation_id: str,
    bearer_token: str | None = None,
) -> AsyncGenerator[SSEEvent, None]:
    """Handle a denied action — let the LLM respond with alternatives."""
    pending = await approval_store.deny(session_id, action_id, reason)
    if not pending:
        yield ErrorEvent(message="Action not found or expired", recoverable=False)
        return

    tool_name = pending.get("tool", "")
    denial_msg = f"User denied the action '{tool_name}'"
    if reason:
        denial_msg += f": {reason}"
    await session_store.append_message(session_id, {"role": "user", "content": denial_msg})

    audit_logger.log_event(
        AuditEventType.APPROVAL_DENIED, session_id=session_id,
        user_id=user_id, correlation_id=correlation_id,
        data={"action_id": action_id, "tool": tool_name, "reason": reason},
    )

    tools = tool_policy.filter_tools(mcp_client.get_tools())
    async for event in _run_auto_mode(session_id, tools, user_id, correlation_id, bearer_token):
        yield event


# ═══════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════


def _get_tool_schema(tool_name: str) -> dict[str, Any]:
    """Look up the JSON schema for a tool by name from the MCP cache."""
    for tool in mcp_client.get_tools_raw():
        if tool["name"] == tool_name:
            return tool.get("input_schema", {})
    return {}


def _accumulate_usage(total: TokenUsage, usage: dict[str, int]) -> None:
    """Add a single LLM call's token usage to the running total."""
    total.input_tokens += usage.get("input_tokens", 0)
    total.output_tokens += usage.get("output_tokens", 0)
    total.total_tokens = total.input_tokens + total.output_tokens
