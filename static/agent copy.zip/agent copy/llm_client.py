"""LLM client — LiteLLM default with Azure OpenAI fallback."""

from __future__ import annotations

import os
import logging
from typing import Any, AsyncGenerator

import litellm
from openai import AsyncAzureOpenAI

import config

logger = logging.getLogger(__name__)

# Suppress litellm's verbose logging
litellm.suppress_debug_info = True


def _build_azure_client() -> AsyncAzureOpenAI | None:
    """Build Azure OpenAI async client for direct fallback."""
    if not config.AZURE_OPENAI_API_KEY or not config.AZURE_OPENAI_ENDPOINT:
        return None
    return AsyncAzureOpenAI(
        api_key=config.AZURE_OPENAI_API_KEY,
        azure_endpoint=config.AZURE_OPENAI_ENDPOINT,
        api_version=config.AZURE_OPENAI_API_VERSION,
    )


# Set LiteLLM env vars so it can find Azure credentials
os.environ.setdefault("AZURE_API_KEY", config.AZURE_OPENAI_API_KEY or "")
os.environ.setdefault("AZURE_API_BASE", config.AZURE_OPENAI_ENDPOINT or "")
os.environ.setdefault("AZURE_API_VERSION", config.AZURE_OPENAI_API_VERSION)


_azure_client: AsyncAzureOpenAI | None = None


def _get_azure_client() -> AsyncAzureOpenAI | None:
    """Return the cached Azure OpenAI client, building it on first call."""
    global _azure_client
    if _azure_client is None:
        _azure_client = _build_azure_client()
    return _azure_client


# ── Streaming chat (primary interface) ──────────────────────────────────


async def chat_stream(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None = None,
    model: str | None = None,
) -> AsyncGenerator[dict[str, Any], None]:
    """Stream LLM response. Yields chunks with type: 'text_delta' | 'tool_call' | 'done'.

    Tries LiteLLM first; falls back to Azure OpenAI on failure.
    """
    model = model or config.DEFAULT_MODEL

    try:
        async for chunk in _litellm_stream(messages, tools, model):
            yield chunk
    except Exception as e:
        logger.warning("LiteLLM failed (%s), falling back to Azure OpenAI", e)
        azure = _get_azure_client()
        if azure is None:
            raise RuntimeError(
                f"LiteLLM failed and Azure OpenAI fallback is not configured: {e}"
            ) from e
        async for chunk in _azure_stream(azure, messages, tools):
            yield chunk


# ── Non-streaming chat (for compaction summaries, plan parsing) ─────────


async def chat_complete(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None = None,
    model: str | None = None,
    max_tokens: int | None = None,
) -> dict[str, Any]:
    """Non-streaming LLM call. Returns full response dict.

    Used for: compaction summaries, plan mode, injection detection.
    """
    model = model or config.DEFAULT_MODEL
    max_tokens = max_tokens or config.MAX_TOKENS

    try:
        return await _litellm_complete(messages, tools, model, max_tokens)
    except Exception as e:
        logger.warning("LiteLLM failed (%s), falling back to Azure OpenAI", e)
        azure = _get_azure_client()
        if azure is None:
            raise RuntimeError(
                f"LiteLLM failed and Azure OpenAI fallback is not configured: {e}"
            ) from e
        return await _azure_complete(azure, messages, tools, max_tokens)


# ── LiteLLM implementation ──────────────────────────────────────────────


async def _litellm_stream(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    model: str,
) -> AsyncGenerator[dict[str, Any], None]:
    """Stream a chat completion via LiteLLM, accumulating tool call deltas."""
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": config.MAX_TOKENS,
        "stream": True,
    }
    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    response = await litellm.acompletion(**kwargs)

    # Accumulate tool calls across deltas
    tool_calls_acc: dict[int, dict[str, Any]] = {}
    finish_reason: str | None = None
    usage: dict[str, int] = {}

    async for chunk in response:
        delta = chunk.choices[0].delta if chunk.choices else None
        finish_reason = chunk.choices[0].finish_reason if chunk.choices else finish_reason

        if delta and getattr(delta, "content", None):
            yield {"type": "text_delta", "delta": delta.content}

        if delta and getattr(delta, "tool_calls", None):
            for tc in delta.tool_calls:
                idx = tc.index
                if idx not in tool_calls_acc:
                    tool_calls_acc[idx] = {
                        "id": tc.id or "",
                        "name": "",
                        "arguments": "",
                    }
                if tc.id:
                    tool_calls_acc[idx]["id"] = tc.id
                if tc.function and tc.function.name:
                    tool_calls_acc[idx]["name"] = tc.function.name
                if tc.function and tc.function.arguments:
                    tool_calls_acc[idx]["arguments"] += tc.function.arguments

        if hasattr(chunk, "usage") and chunk.usage:
            usage = {
                "input_tokens": getattr(chunk.usage, "prompt_tokens", 0) or 0,
                "output_tokens": getattr(chunk.usage, "completion_tokens", 0) or 0,
            }

    # Emit accumulated tool calls
    for tc in tool_calls_acc.values():
        import json
        try:
            args = json.loads(tc["arguments"]) if tc["arguments"] else {}
        except json.JSONDecodeError:
            args = {}
        yield {
            "type": "tool_call",
            "id": tc["id"],
            "name": tc["name"],
            "arguments": args,
        }

    yield {
        "type": "done",
        "stop_reason": finish_reason or "end_turn",
        "usage": usage,
    }


async def _litellm_complete(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    model: str,
    max_tokens: int,
) -> dict[str, Any]:
    """Non-streaming chat completion via LiteLLM."""
    kwargs: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    response = await litellm.acompletion(**kwargs)
    choice = response.choices[0]
    message = choice.message

    result: dict[str, Any] = {
        "role": "assistant",
        "content": message.content or "",
        "stop_reason": choice.finish_reason,
        "tool_calls": [],
        "usage": {
            "input_tokens": getattr(response.usage, "prompt_tokens", 0),
            "output_tokens": getattr(response.usage, "completion_tokens", 0),
        },
    }

    if message.tool_calls:
        import json
        for tc in message.tool_calls:
            try:
                args = json.loads(tc.function.arguments) if tc.function.arguments else {}
            except json.JSONDecodeError:
                args = {}
            result["tool_calls"].append({
                "id": tc.id,
                "name": tc.function.name,
                "arguments": args,
            })

    return result


# ── Azure OpenAI fallback ───────────────────────────────────────────────


async def _azure_stream(
    client: AsyncAzureOpenAI,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
) -> AsyncGenerator[dict[str, Any], None]:
    """Stream a chat completion directly via the Azure OpenAI SDK."""
    kwargs: dict[str, Any] = {
        "model": config.AZURE_OPENAI_DEPLOYMENT,
        "messages": messages,
        "max_tokens": config.MAX_TOKENS,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    response = await client.chat.completions.create(**kwargs)

    tool_calls_acc: dict[int, dict[str, Any]] = {}
    finish_reason: str | None = None
    usage: dict[str, int] = {}

    async for chunk in response:
        if not chunk.choices:
            if hasattr(chunk, "usage") and chunk.usage:
                usage = {
                    "input_tokens": chunk.usage.prompt_tokens or 0,
                    "output_tokens": chunk.usage.completion_tokens or 0,
                }
            continue

        delta = chunk.choices[0].delta
        finish_reason = chunk.choices[0].finish_reason or finish_reason

        if delta and delta.content:
            yield {"type": "text_delta", "delta": delta.content}

        if delta and delta.tool_calls:
            for tc in delta.tool_calls:
                idx = tc.index
                if idx not in tool_calls_acc:
                    tool_calls_acc[idx] = {"id": "", "name": "", "arguments": ""}
                if tc.id:
                    tool_calls_acc[idx]["id"] = tc.id
                if tc.function and tc.function.name:
                    tool_calls_acc[idx]["name"] = tc.function.name
                if tc.function and tc.function.arguments:
                    tool_calls_acc[idx]["arguments"] += tc.function.arguments

    import json
    for tc in tool_calls_acc.values():
        try:
            args = json.loads(tc["arguments"]) if tc["arguments"] else {}
        except json.JSONDecodeError:
            args = {}
        yield {
            "type": "tool_call",
            "id": tc["id"],
            "name": tc["name"],
            "arguments": args,
        }

    yield {
        "type": "done",
        "stop_reason": finish_reason or "end_turn",
        "usage": usage,
    }


async def _azure_complete(
    client: AsyncAzureOpenAI,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    max_tokens: int,
) -> dict[str, Any]:
    """Non-streaming chat completion directly via the Azure OpenAI SDK."""
    kwargs: dict[str, Any] = {
        "model": config.AZURE_OPENAI_DEPLOYMENT,
        "messages": messages,
        "max_tokens": max_tokens,
    }
    if tools:
        kwargs["tools"] = tools
        kwargs["tool_choice"] = "auto"

    response = await client.chat.completions.create(**kwargs)
    choice = response.choices[0]
    message = choice.message

    result: dict[str, Any] = {
        "role": "assistant",
        "content": message.content or "",
        "stop_reason": choice.finish_reason,
        "tool_calls": [],
        "usage": {
            "input_tokens": response.usage.prompt_tokens if response.usage else 0,
            "output_tokens": response.usage.completion_tokens if response.usage else 0,
        },
    }

    if message.tool_calls:
        import json
        for tc in message.tool_calls:
            try:
                args = json.loads(tc.function.arguments) if tc.function.arguments else {}
            except json.JSONDecodeError:
                args = {}
            result["tool_calls"].append({
                "id": tc.id,
                "name": tc.function.name,
                "arguments": args,
            })

    return result


# ── Health check ────────────────────────────────────────────────────────


async def ping() -> bool:
    """Quick check — can we reach the default LLM?"""
    try:
        resp = await litellm.acompletion(
            model=config.DEFAULT_MODEL,
            messages=[{"role": "user", "content": "ping"}],
            max_tokens=5,
        )
        return bool(resp.choices)
    except Exception:
        return False
