"""Redis-backed session store for multi-turn conversations."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

import redis.asyncio as aioredis

import config

logger = logging.getLogger(__name__)

_pool: aioredis.Redis | None = None


async def init_redis() -> None:
    """Create the shared Redis connection pool and verify connectivity."""
    global _pool
    _pool = aioredis.from_url(
        config.REDIS_URL,
        decode_responses=True,
        max_connections=20,
    )
    await _pool.ping()
    logger.info("Redis connected: %s", config.REDIS_URL)


async def close_redis() -> None:
    """Gracefully close the Redis connection pool."""
    global _pool
    if _pool:
        await _pool.aclose()
        _pool = None


def _r() -> aioredis.Redis:
    """Return the active Redis connection, raising if not initialised."""
    if _pool is None:
        raise RuntimeError("Redis not initialised — call init_redis() first")
    return _pool


def _session_key(session_id: str) -> str:
    """Build the Redis hash key for a session."""
    return f"session:{session_id}"


def _loop_state_key(session_id: str) -> str:
    """Build the Redis hash key for agent loop state checkpoints."""
    return f"loop_state:{session_id}"


def _sse_buffer_key(session_id: str) -> str:
    """Build the Redis sorted-set key for SSE event replay buffer."""
    return f"sse_events:{session_id}"


# ── Session CRUD ────────────────────────────────────────────────────────


async def create_session(mode: str = "auto") -> dict[str, Any]:
    """Create a new session in Redis and return its metadata."""
    session_id = uuid4().hex
    now = datetime.now(timezone.utc).isoformat()
    data = {
        "session_id": session_id,
        "messages": json.dumps([]),
        "mode": mode,
        "created_at": now,
        "last_active": now,
        "tool_call_count": "0",
        "destructive_action_count": "0",
    }
    r = _r()
    await r.hset(_session_key(session_id), mapping=data)
    await r.expire(_session_key(session_id), config.SESSION_TTL)
    logger.info("Session created: %s", session_id)
    return {"session_id": session_id, "mode": mode, "created_at": now}


async def get_session(session_id: str) -> dict[str, Any] | None:
    """Retrieve session data by ID, or None if not found."""
    r = _r()
    data = await r.hgetall(_session_key(session_id))
    if not data:
        return None
    data["messages"] = json.loads(data.get("messages", "[]"))
    data["tool_call_count"] = int(data.get("tool_call_count", 0))
    data["destructive_action_count"] = int(data.get("destructive_action_count", 0))
    return data


async def delete_session(session_id: str) -> bool:
    """Delete a session and all its associated keys. Returns True if anything was deleted."""
    r = _r()
    deleted = await r.delete(
        _session_key(session_id),
        _loop_state_key(session_id),
        _sse_buffer_key(session_id),
    )
    return deleted > 0


async def touch_session(session_id: str) -> None:
    """Update last_active and reset TTL."""
    r = _r()
    key = _session_key(session_id)
    await r.hset(key, "last_active", datetime.now(timezone.utc).isoformat())
    await r.expire(key, config.SESSION_TTL)


# ── Message management ──────────────────────────────────────────────────


async def get_messages(session_id: str) -> list[dict[str, Any]]:
    """Return the full message history for a session."""
    r = _r()
    raw = await r.hget(_session_key(session_id), "messages")
    if not raw:
        return []
    return json.loads(raw)


async def append_message(session_id: str, message: dict[str, Any]) -> None:
    """Append a timestamped message to the session history and refresh TTL."""
    r = _r()
    key = _session_key(session_id)
    raw = await r.hget(key, "messages")
    messages = json.loads(raw) if raw else []
    message["timestamp"] = datetime.now(timezone.utc).isoformat()
    messages.append(message)
    await r.hset(key, "messages", json.dumps(messages))
    await touch_session(session_id)


async def set_messages(session_id: str, messages: list[dict[str, Any]]) -> None:
    """Replace entire message history (used after compaction)."""
    r = _r()
    await r.hset(_session_key(session_id), "messages", json.dumps(messages))


# ── Counters ────────────────────────────────────────────────────────────


async def increment_tool_calls(session_id: str, count: int = 1) -> int:
    """Atomically increment the session's tool call counter."""
    r = _r()
    return await r.hincrby(_session_key(session_id), "tool_call_count", count)


async def increment_destructive_actions(session_id: str, count: int = 1) -> int:
    """Atomically increment the session's destructive action counter."""
    r = _r()
    return await r.hincrby(_session_key(session_id), "destructive_action_count", count)


# ── Loop state checkpoint ───────────────────────────────────────────────


async def save_loop_state(session_id: str, state: dict[str, Any]) -> None:
    """Persist an agent loop checkpoint for crash recovery."""
    r = _r()
    key = _loop_state_key(session_id)
    state["last_checkpoint"] = datetime.now(timezone.utc).isoformat()
    await r.hset(key, mapping={k: json.dumps(v) if isinstance(v, (dict, list)) else str(v) for k, v in state.items()})
    await r.expire(key, config.SESSION_TTL)


async def get_loop_state(session_id: str) -> dict[str, Any] | None:
    """Retrieve the last agent loop checkpoint, or None if absent."""
    r = _r()
    data = await r.hgetall(_loop_state_key(session_id))
    if not data:
        return None
    # Parse JSON fields
    for key in ("pending_tools", "partial_content"):
        if key in data:
            try:
                data[key] = json.loads(data[key])
            except (json.JSONDecodeError, TypeError):
                pass
    return data


async def delete_loop_state(session_id: str) -> None:
    """Remove the agent loop checkpoint for a session."""
    r = _r()
    await r.delete(_loop_state_key(session_id))


# ── SSE event buffer (for reconnection replay) ─────────────────────────


async def buffer_sse_event(session_id: str, event_id: int, event_data: str) -> None:
    """Buffer an SSE event in Redis for client reconnection replay."""
    r = _r()
    key = _sse_buffer_key(session_id)
    await r.zadd(key, {event_data: event_id})
    await r.zremrangebyrank(key, 0, -(config.SSE_EVENT_BUFFER_MAX + 1))
    await r.expire(key, config.SSE_EVENT_BUFFER_TTL)


async def get_sse_events_after(session_id: str, last_event_id: int) -> list[str]:
    """Return buffered SSE events with IDs greater than last_event_id."""
    r = _r()
    key = _sse_buffer_key(session_id)
    return await r.zrangebyscore(key, last_event_id + 1, "+inf")


# ── Health ──────────────────────────────────────────────────────────────


async def ping() -> bool:
    """Return True if Redis is reachable."""
    try:
        r = _r()
        return await r.ping()
    except Exception:
        return False
