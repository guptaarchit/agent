"""SSE stream helpers — thin wrapper around models.events for convenience."""

from __future__ import annotations

from typing import Any, AsyncGenerator

from models.events import (
    ApprovalRequiredEvent,
    ApprovalResultEvent,
    DoneEvent,
    ErrorEvent,
    FileAvailableEvent,
    PlanEvent,
    RecoveryEvent,
    SessionCreatedEvent,
    SSEEvent,
    TextDeltaEvent,
    ThinkingEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from models.common import Plan, TokenUsage

# Re-export all event classes for easy imports
__all__ = [
    "ApprovalRequiredEvent",
    "ApprovalResultEvent",
    "DoneEvent",
    "ErrorEvent",
    "FileAvailableEvent",
    "PlanEvent",
    "RecoveryEvent",
    "SessionCreatedEvent",
    "SSEEvent",
    "TextDeltaEvent",
    "ThinkingEvent",
    "ToolCallEvent",
    "ToolResultEvent",
    "format_sse_stream",
]


async def format_sse_stream(
    events: AsyncGenerator[SSEEvent, None],
) -> AsyncGenerator[str, None]:
    """Convert a stream of SSEEvent objects into formatted SSE strings with auto-incrementing IDs."""
    event_id = 0
    async for event in events:
        event_id += 1
        yield event.to_sse(event_id=event_id)
