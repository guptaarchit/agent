from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .common import SessionInfo, TokenUsage


class HealthResponse(BaseModel):
    status: str  # "healthy" | "degraded" | "unhealthy"
    mcp_connected: bool
    redis_connected: bool
    llm_reachable: bool
    details: dict[str, Any] = {}


class ToolInfo(BaseModel):
    name: str
    description: str = ""
    input_schema: dict[str, Any] = {}
    is_destructive: bool = False
    is_allowed: bool = True


class ToolListResponse(BaseModel):
    tools: list[ToolInfo]
    count: int
    last_refresh: str | None = None


class HistoryMessage(BaseModel):
    role: str
    content: Any
    timestamp: str | None = None
    tool_name: str | None = None


class HistoryResponse(BaseModel):
    session: SessionInfo
    messages: list[HistoryMessage]
    token_usage: TokenUsage


class FileResponse(BaseModel):
    file_id: str
    filename: str
    size_bytes: int
    mime_type: str
    download_url: str
