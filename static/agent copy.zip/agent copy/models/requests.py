from __future__ import annotations

from pydantic import BaseModel, Field

from .common import ExecutionMode


class ChatRequest(BaseModel):
    session_id: str | None = None
    message: str = Field(..., min_length=1, max_length=10_000)
    mode: ExecutionMode = ExecutionMode.AUTO
    idempotency_key: str | None = None


class ApproveRequest(BaseModel):
    """Body is optional — action_id is in the URL path."""
    pass


class DenyRequest(BaseModel):
    reason: str | None = None
