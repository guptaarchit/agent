from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class ExecutionMode(StrEnum):
    AUTO = "auto"
    PLAN = "plan"


class ActionStatus(StrEnum):
    PENDING = "pending"
    EXECUTING = "executing"
    COMPLETED = "completed"
    DENIED = "denied"


class LoopStatus(StrEnum):
    RUNNING = "running"
    PAUSED_APPROVAL = "paused_approval"
    COMPLETED = "completed"
    FAILED = "failed"


class ToolCallRecord(BaseModel):
    tool: str
    arguments: dict[str, Any] = {}
    type: str = "read"  # "read" | "destructive"
    description: str = ""


class PlanStep(BaseModel):
    step: int
    tool: str
    arguments: dict[str, Any] = {}
    type: str = "read"
    description: str = ""


class Plan(BaseModel):
    plan_id: str
    summary: str
    steps: list[PlanStep]


class SessionInfo(BaseModel):
    session_id: str
    mode: ExecutionMode = ExecutionMode.AUTO
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_active: datetime = Field(default_factory=datetime.utcnow)


class TokenUsage(BaseModel):
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    estimated_cost_usd: float = 0.0
