from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from .common import Plan, TokenUsage


class SSEEvent(BaseModel):
    """Base class for all SSE events. The `type` field is used by the UI to dispatch."""
    type: str

    def to_sse(self, event_id: int | None = None) -> str:
        """Serialize this event into an SSE-formatted string."""
        parts: list[str] = []
        if event_id is not None:
            parts.append(f"id: {event_id}")
        parts.append(f"event: {self.type}")
        parts.append(f"data: {self.model_dump_json()}")
        parts.append("")
        return "\n".join(parts) + "\n"


class SessionCreatedEvent(SSEEvent):
    type: str = "session_created"
    session_id: str


class ThinkingEvent(SSEEvent):
    type: str = "thinking"
    message: str


class ToolCallEvent(SSEEvent):
    type: str = "tool_call"
    tool: str
    arguments: dict[str, Any] = {}


class ToolResultEvent(SSEEvent):
    type: str = "tool_result"
    tool: str
    result: Any
    is_error: bool = False
    duration_ms: int | None = None


class TextDeltaEvent(SSEEvent):
    type: str = "text_delta"
    delta: str


class PlanEvent(SSEEvent):
    type: str = "plan"
    plan: Plan


class PlanApprovedEvent(SSEEvent):
    type: str = "plan_approved"
    plan_id: str


class ApprovalRequiredEvent(SSEEvent):
    type: str = "approval_required"
    action_id: str
    tool: str
    arguments: dict[str, Any] = {}
    description: str


class ApprovalResultEvent(SSEEvent):
    type: str = "approval_result"
    action_id: str
    approved: bool
    result: Any = None


class FileAvailableEvent(SSEEvent):
    type: str = "file_available"
    file_id: str
    filename: str
    size_bytes: int
    mime_type: str
    tool: str
    download_url: str


class RecoveryEvent(SSEEvent):
    type: str = "recovery"
    message: str = "Resuming interrupted session..."


class DataChunkEvent(SSEEvent):
    """Raw data streamed directly to UI for large tool results (not sent to LLM)."""
    type: str = "data_chunk"
    tool: str
    chunk_index: int
    total_chunks: int
    data: Any
    format: str = "json"  # "json" | "text" | "table"


class ErrorEvent(SSEEvent):
    type: str = "error"
    message: str
    recoverable: bool = True


class DoneEvent(SSEEvent):
    type: str = "done"
    summary: str = ""
    tools_used: list[str] = []
    token_usage: TokenUsage | None = None
