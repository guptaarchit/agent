"""FastAPI application — REST API with SSE streaming, versioned under /v1/."""

from __future__ import annotations

import asyncio
import logging
import sys
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Annotated, Any
from uuid import uuid4

from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pythonjsonlogger import jsonlogger
from sse_starlette.sse import EventSourceResponse

import agent
import config
import file_store
import memory
import session_store
from guardrails import audit_logger, rate_limiter
from guardrails.audit_logger import AuditEventType
from mcp_client import mcp_client
from middleware.auth import AuthContext, get_current_user

Auth = Annotated[AuthContext, Depends(get_current_user)]
from middleware.circuit_breaker import mcp_circuit_breaker
from models.events import SSEEvent
from models.requests import ChatRequest, DenyRequest
from models.responses import (
    HealthResponse,
    HistoryMessage,
    HistoryResponse,
    ToolInfo,
    ToolListResponse,
)
from models.common import SessionInfo, TokenUsage

# ── Logging setup ───────────────────────────────────────────────────────

_log_handler = logging.StreamHandler(sys.stdout)
_log_handler.setFormatter(
    jsonlogger.JsonFormatter(
        fmt="%(asctime)s %(levelname)s %(name)s %(message)s",
        rename_fields={"asctime": "timestamp", "levelname": "level"},
    )
)
logging.root.handlers = [_log_handler]
logging.root.setLevel(config.LOG_LEVEL)

logger = logging.getLogger(__name__)


# ── App lifecycle ───────────────────────────────────────────────────────


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage startup (Redis, MCP, memory) and shutdown cleanup."""
    # Startup
    logger.info("Starting agent server (env=%s)", config.ENVIRONMENT)
    await session_store.init_redis()
    await memory.init_memory()
    await file_store.init_file_store()
    await mcp_client.connect()

    # Background: MCP tool refresh
    refresh_task = asyncio.create_task(_mcp_refresh_loop())
    # Background: file cleanup
    cleanup_task = asyncio.create_task(_file_cleanup_loop())

    yield

    # Shutdown
    logger.info("Shutting down agent server")
    refresh_task.cancel()
    cleanup_task.cancel()
    await mcp_client.disconnect()
    await session_store.close_redis()


app = FastAPI(
    title="ATS Cloud Agent API",
    description="AI agent for managing cloud resources via MCP",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Chat UI
STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def serve_ui():
    """Serve the chat UI."""
    return FileResponse(str(STATIC_DIR / "index.html"))


# ── Correlation ID middleware ───────────────────────────────────────────


@app.middleware("http")
async def add_correlation_id(request: Request, call_next):
    """Attach a correlation ID to every request/response for tracing."""
    correlation_id = request.headers.get("X-Correlation-ID", uuid4().hex[:16])
    request.state.correlation_id = correlation_id
    response = await call_next(request)
    response.headers["X-Correlation-ID"] = correlation_id
    return response


# ── Background tasks ────────────────────────────────────────────────────


async def _mcp_refresh_loop():
    """Periodically refresh the MCP tool cache in the background."""
    while True:
        await asyncio.sleep(config.MCP_TOOL_REFRESH_INTERVAL)
        try:
            changed = await mcp_client.refresh_tools()
            if changed:
                logger.info("MCP tools changed on refresh")
        except Exception as e:
            logger.warning("MCP tool refresh failed: %s", e)


async def _file_cleanup_loop():
    """Periodically remove expired temporary files."""
    while True:
        await asyncio.sleep(300)  # every 5 min
        try:
            await file_store.cleanup_expired()
        except Exception as e:
            logger.warning("File cleanup failed: %s", e)


# ── Helper: collect events into JSON response ──────────────────────────


async def _collect_response(events_gen) -> dict[str, Any]:
    """Collect all SSE events into a single JSON response.

    Returns a structured dict with session info, text response,
    tool calls/results, data tables, approval requests, and metadata.
    """
    result: dict[str, Any] = {
        "session_id": None,
        "status": "done",
        "text": "",
        "tool_calls": [],
        "tool_results": [],
        "data": [],         # raw data from data_chunk events (for tables)
        "files": [],
        "approval": None,   # set if approval_required
        "plan": None,       # set if plan mode
        "errors": [],
        "tools_used": [],
        "token_usage": None,
    }

    async for event in events_gen:
        etype = event.type
        edata = event.model_dump()

        if etype == "session_created":
            result["session_id"] = edata["session_id"]

        elif etype == "text_delta":
            result["text"] += edata["delta"]

        elif etype == "tool_call":
            result["tool_calls"].append({"tool": edata["tool"], "arguments": edata["arguments"]})

        elif etype == "tool_result":
            result["tool_results"].append({
                "tool": edata["tool"],
                "result": edata["result"],
                "is_error": edata["is_error"],
                "duration_ms": edata.get("duration_ms"),
            })

        elif etype == "data_chunk":
            result["data"].append({
                "tool": edata["tool"],
                "chunk_index": edata["chunk_index"],
                "total_chunks": edata["total_chunks"],
                "data": edata["data"],
                "format": edata.get("format", "json"),
            })

        elif etype == "file_available":
            result["files"].append(edata)

        elif etype == "approval_required":
            result["status"] = "approval_required"
            result["approval"] = {
                "action_id": edata["action_id"],
                "tool": edata["tool"],
                "arguments": edata["arguments"],
                "description": edata["description"],
            }

        elif etype == "plan":
            result["status"] = "plan_pending"
            result["plan"] = edata["plan"]

        elif etype == "error":
            result["errors"].append(edata["message"])
            if not edata.get("recoverable", True):
                result["status"] = "error"

        elif etype == "done":
            result["tools_used"] = edata.get("tools_used", [])
            result["token_usage"] = edata.get("token_usage")

    return result


# ═══════════════════════════════════════════════════════════════════════
# ENDPOINTS — /v1/
# ═══════════════════════════════════════════════════════════════════════


@app.post("/v1/chat")
async def chat(
    request: Request,
    body: ChatRequest,
    auth: Auth,
):
    """Send a message, receive full JSON response with text, tool results, and data tables."""
    correlation_id = getattr(request.state, "correlation_id", "")

    # Rate limit
    allowed, remaining = await rate_limiter.check_rate_limit(auth.user_id, "chat")
    if not allowed:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded",
            headers={"Retry-After": "60"},
        )

    events = agent.run_chat(
        session_id=body.session_id,
        message=body.message,
        mode=body.mode,
        user_id=auth.user_id,
        correlation_id=correlation_id,
        bearer_token=auth.bearer_token,
    )

    return await _collect_response(events)


@app.post("/v1/chat/{session_id}/approve/{action_id}")
async def approve_action(
    request: Request,
    session_id: str,
    action_id: str,
    auth: Auth,
):
    """Approve a pending destructive action or plan. Returns JSON."""
    correlation_id = getattr(request.state, "correlation_id", "")

    allowed, _ = await rate_limiter.check_rate_limit(auth.user_id, "approve")
    if not allowed:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    events = agent.resume_after_approval(
        session_id, action_id, auth.user_id, correlation_id,
        bearer_token=auth.bearer_token,
    )
    return await _collect_response(events)


@app.post("/v1/chat/{session_id}/deny/{action_id}")
async def deny_action(
    request: Request,
    session_id: str,
    action_id: str,
    auth: Auth,
    body: DenyRequest | None = None,
):
    """Deny a pending destructive action or plan. Returns JSON."""
    correlation_id = getattr(request.state, "correlation_id", "")
    reason = body.reason if body else ""

    events = agent.resume_after_denial(
        session_id, action_id, reason or "", auth.user_id, correlation_id,
        bearer_token=auth.bearer_token,
    )
    return await _collect_response(events)


@app.get("/v1/chat/{session_id}/history")
async def get_history(
    session_id: str,
    auth: Auth,
):
    """Get full conversation history for a session."""
    allowed, _ = await rate_limiter.check_rate_limit(auth.user_id, "history")
    if not allowed:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")

    session = await session_store.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    messages = [
        HistoryMessage(
            role=m.get("role", ""),
            content=m.get("content", ""),
            timestamp=m.get("timestamp"),
            tool_name=m.get("tool_name"),
        )
        for m in session.get("messages", [])
    ]

    return HistoryResponse(
        session=SessionInfo(
            session_id=session_id,
            mode=session.get("mode", "auto"),
            created_at=session.get("created_at", ""),
            last_active=session.get("last_active", ""),
        ),
        messages=messages,
        token_usage=TokenUsage(),
    )


@app.get("/v1/chat/{session_id}/stream")
async def reconnect_stream(
    request: Request,
    session_id: str,
    _auth: Auth,
):
    """Reconnect SSE stream — replay missed events via Last-Event-ID."""
    last_event_id = request.headers.get("Last-Event-ID")
    if not last_event_id:
        raise HTTPException(status_code=400, detail="Last-Event-ID header required")

    events = await session_store.get_sse_events_after(session_id, int(last_event_id))

    async def replay():
        for event_str in events:
            yield {"data": event_str}

    return EventSourceResponse(replay())


@app.delete("/v1/chat/{session_id}")
async def delete_session(
    session_id: str,
    auth: Auth,
):
    """Delete a session and its data."""
    deleted = await session_store.delete_session(session_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Session not found")

    audit_logger.log_event(
        AuditEventType.SESSION_DELETED,
        session_id=session_id,
        user_id=auth.user_id,
    )
    return {"status": "deleted", "session_id": session_id}


@app.get("/v1/tools")
async def list_tools(_auth: AuthContext = Depends(get_current_user)):
    """List all available MCP tools."""
    raw_tools = mcp_client.get_tools_raw()
    tools = [
        ToolInfo(
            name=t["name"],
            description=t.get("description", ""),
            input_schema=t.get("input_schema", {}),
            is_destructive=config.is_destructive_tool(t["name"]),
            is_allowed=(
                t["name"] not in config.TOOL_BLOCKLIST
                and (config.TOOL_ALLOWLIST is None or t["name"] in config.TOOL_ALLOWLIST)
            ),
        )
        for t in raw_tools
    ]
    return ToolListResponse(
        tools=tools,
        count=len(tools),
        last_refresh=mcp_client.last_refresh.isoformat() if mcp_client.last_refresh else None,
    )


@app.post("/v1/tools/refresh")
async def refresh_tools(_auth: AuthContext = Depends(get_current_user)):
    """Force re-fetch MCP tool list."""
    changed = await mcp_client.refresh_tools()
    return {
        "changed": changed,
        "tool_count": mcp_client.tool_count,
        "checksum": mcp_client.checksum,
    }


@app.get("/v1/files/{file_id}")
async def download_file(
    file_id: str,
    _auth: Auth,
):
    """Download a file generated by an MCP tool."""
    meta = await file_store.get_file(file_id)
    if not meta:
        raise HTTPException(status_code=404, detail="File not found or expired")

    data = await file_store.read_file(file_id)
    if not data:
        raise HTTPException(status_code=404, detail="File content not found")

    return Response(
        content=data,
        media_type=meta["mime_type"],
        headers={"Content-Disposition": f'attachment; filename="{meta["filename"]}"'},
    )


@app.get("/v1/health")
async def health_check():
    """Health check — MCP, Redis, LLM reachability."""
    import llm_client as llm

    mcp_ok = await mcp_client.ping()
    redis_ok = await session_store.ping()
    llm_ok = await llm.ping()

    all_ok = mcp_ok and redis_ok and llm_ok
    degraded = not all_ok and (redis_ok or mcp_ok)

    return HealthResponse(
        status="healthy" if all_ok else ("degraded" if degraded else "unhealthy"),
        mcp_connected=mcp_ok,
        redis_connected=redis_ok,
        llm_reachable=llm_ok,
        details={
            "circuit_breaker": mcp_circuit_breaker.status(),
            "mcp_tools": mcp_client.tool_count,
            "environment": config.ENVIRONMENT,
        },
    )


# ── Entrypoint ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=config.HOST,
        port=config.PORT,
        reload=config.ENVIRONMENT == "dev",
        log_level=config.LOG_LEVEL.lower(),
    )
