"""Persistent Session State — tracks context across turns without bloating the LLM prompt.

Stored in Redis as a small JSON block. Injected into every LLM call so it knows:
- What resource the user is currently focused on
- Which tool group was last used
- Active aliases and filters
"""

from __future__ import annotations

import json
import logging
from typing import Any

import config
from session_store import _r

logger = logging.getLogger(__name__)


def _state_key(session_id: str) -> str:
    return f"session_state:{session_id}"


# ── Default State ───────────────────────────────────────────────────────

_DEFAULT_STATE = {
    "active_group": None,           # last tool group used (for routing continuity)
    "last_tool": None,              # last successful tool name
    "last_resource_type": None,     # e.g. "project", "vm"
    "focused_alias": None,          # e.g. "proj-3" — the resource user is asking about
    "focused_resource_id": None,    # real ID of the focused resource
    "focused_resource_name": None,  # display name
    "active_filters": {},           # e.g. {"landscape": "Prod", "created_by": "archigup"}
    "turn_count": 0,
}


# ── CRUD ────────────────────────────────────────────────────────────────


async def get_state(session_id: str) -> dict[str, Any]:
    """Get the current session state, or defaults if none exists."""
    r = _r()
    raw = await r.get(_state_key(session_id))
    if not raw:
        return dict(_DEFAULT_STATE)
    state = json.loads(raw)
    # Merge with defaults for any missing keys
    for k, v in _DEFAULT_STATE.items():
        if k not in state:
            state[k] = v
    return state


async def update_state(session_id: str, **updates) -> dict[str, Any]:
    """Update specific fields in the session state."""
    state = await get_state(session_id)
    state.update(updates)
    state["turn_count"] = state.get("turn_count", 0) + 1
    r = _r()
    await r.set(_state_key(session_id), json.dumps(state, default=str), ex=config.SESSION_TTL)
    return state


async def clear_state(session_id: str) -> None:
    """Reset session state."""
    r = _r()
    await r.delete(_state_key(session_id))


# ── State Block for LLM ────────────────────────────────────────────────


def format_state_for_llm(state: dict[str, Any]) -> str:
    """Format the session state as a compact block to inject into the LLM prompt.

    This gives the LLM continuity across turns without needing full history.
    """
    parts = ["[Session Context]"]

    if state.get("active_group"):
        parts.append(f"Active area: {state['active_group']}")

    if state.get("last_tool"):
        parts.append(f"Last tool used: {state['last_tool']}")

    if state.get("focused_alias"):
        parts.append(
            f"User is focused on: {state['focused_alias']} "
            f"(name={state.get('focused_resource_name', '?')}, "
            f"id={state.get('focused_resource_id', '?')})"
        )

    if state.get("active_filters"):
        filters = ", ".join(f"{k}={v}" for k, v in state["active_filters"].items())
        parts.append(f"Active filters: {filters}")

    if len(parts) == 1:
        return ""  # no meaningful state yet

    return "\n".join(parts)
