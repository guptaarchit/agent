"""Temporary file storage for artifacts returned by MCP tools."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any
from uuid import uuid4

import aiofiles

import config

logger = logging.getLogger(__name__)

# In-memory metadata registry
_files: dict[str, dict[str, Any]] = {}


async def init_file_store() -> None:
    """Ensure the file storage directory exists."""
    os.makedirs(config.FILE_STORE_DIR, exist_ok=True)
    logger.info("File store initialised: %s", config.FILE_STORE_DIR)


async def store_file(
    data: bytes,
    filename: str,
    mime_type: str,
    session_id: str,
    tool_name: str = "",
) -> dict[str, Any]:
    """Store a file and return metadata with file_id."""
    file_id = f"f_{uuid4().hex[:12]}"
    safe_name = os.path.basename(filename)
    if not safe_name or safe_name in (".", ".."):
        safe_name = f"{file_id}.bin"

    path = os.path.join(config.FILE_STORE_DIR, f"{file_id}_{safe_name}")
    async with aiofiles.open(path, "wb") as f:
        await f.write(data)

    meta = {
        "file_id": file_id,
        "filename": safe_name,
        "path": path,
        "size_bytes": len(data),
        "mime_type": mime_type,
        "session_id": session_id,
        "tool_name": tool_name,
        "created_at": time.time(),
        "download_url": f"/v1/files/{file_id}",
    }
    _files[file_id] = meta
    logger.info("File stored: %s (%d bytes) from tool=%s", file_id, len(data), tool_name)
    return meta


async def get_file(file_id: str) -> dict[str, Any] | None:
    """Return file metadata, or None if not found/expired."""
    meta = _files.get(file_id)
    if not meta:
        return None
    if time.time() - meta["created_at"] > config.FILE_TTL:
        await delete_file(file_id)
        return None
    return meta


async def read_file(file_id: str) -> bytes | None:
    """Read file content by ID."""
    meta = await get_file(file_id)
    if not meta:
        return None
    try:
        async with aiofiles.open(meta["path"], "rb") as f:
            return await f.read()
    except FileNotFoundError:
        return None


async def delete_file(file_id: str) -> None:
    """Remove a file from disk and the in-memory registry."""
    meta = _files.pop(file_id, None)
    if meta and os.path.exists(meta["path"]):
        os.remove(meta["path"])


async def cleanup_expired() -> int:
    """Remove files older than FILE_TTL. Returns count of removed files."""
    now = time.time()
    expired = [
        fid for fid, meta in _files.items()
        if now - meta["created_at"] > config.FILE_TTL
    ]
    for fid in expired:
        await delete_file(fid)
    if expired:
        logger.info("Cleaned up %d expired files", len(expired))
    return len(expired)
