"""MCP client — connects to ATS Cloud MCP server, discovers tools, executes tool calls."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

import config

logger = logging.getLogger(__name__)


class MCPClient:
    """Manages connections to the MCP server.

    Uses a service-level connection for tool discovery and per-call
    connections with the user's Bearer token for tool execution.
    """

    def __init__(self) -> None:
        self._session: ClientSession | None = None
        self._client_ctx: Any = None
        self._read_stream: Any = None
        self._write_stream: Any = None

        # Cached tool list
        self._tools: list[dict[str, Any]] = []
        self._tools_raw: list[Any] = []  # raw MCP tool objects
        self._last_refresh: datetime | None = None
        self._checksum: str = ""

    # ── Connection lifecycle (service-level, for tool discovery) ─────

    async def connect(self) -> None:
        """Open service-level connection for tool discovery."""
        logger.info("Connecting to MCP server: %s", config.MCP_SERVER_URL)
        self._client_ctx = streamablehttp_client(
            config.MCP_SERVER_URL,
            headers=config.mcp_headers(),  # uses service token if available
        )
        streams = await self._client_ctx.__aenter__()
        self._read_stream, self._write_stream = streams[0], streams[1]

        self._session = ClientSession(self._read_stream, self._write_stream)
        await self._session.__aenter__()
        await self._session.initialize()
        logger.info("MCP connection established")

        # Warm the tool cache
        await self.refresh_tools()

    async def disconnect(self) -> None:
        """Close connection cleanly."""
        if self._session:
            try:
                await self._session.__aexit__(None, None, None)
            except Exception:
                pass
        if self._client_ctx:
            try:
                await self._client_ctx.__aexit__(None, None, None)
            except Exception:
                pass
        self._session = None
        logger.info("MCP connection closed")

    @property
    def is_connected(self) -> bool:
        return self._session is not None

    # ── Tool discovery ──────────────────────────────────────────────────

    async def refresh_tools(self) -> bool:
        """Fetch tool list from MCP server. Returns True if tools changed."""
        if not self._session:
            raise RuntimeError("MCP client not connected")

        result = await self._session.list_tools()
        raw_tools = result.tools

        # Build serialisable tool list
        tools = []
        for t in raw_tools:
            tools.append({
                "name": t.name,
                "description": t.description or "",
                "input_schema": t.inputSchema if hasattr(t, "inputSchema") else {},
            })

        # Check if tools changed
        new_checksum = hashlib.md5(
            json.dumps(tools, sort_keys=True).encode()
        ).hexdigest()

        changed = new_checksum != self._checksum
        if changed:
            old_count = len(self._tools)
            self._tools = tools
            self._tools_raw = raw_tools
            self._checksum = new_checksum
            logger.info(
                "MCP tools refreshed: %d tools (was %d), checksum=%s",
                len(tools), old_count, new_checksum[:8],
            )
        self._last_refresh = datetime.now(timezone.utc)
        return changed

    def get_tools(self) -> list[dict[str, Any]]:
        """Return cached tool list in LiteLLM/OpenAI tool format."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t["description"],
                    "parameters": t["input_schema"],
                },
            }
            for t in self._tools
        ]

    def get_tools_raw(self) -> list[dict[str, Any]]:
        """Return cached tool list as plain dicts (for /tools endpoint)."""
        return list(self._tools)

    @property
    def tool_count(self) -> int:
        return len(self._tools)

    @property
    def last_refresh(self) -> datetime | None:
        return self._last_refresh

    @property
    def checksum(self) -> str:
        return self._checksum

    # ── Tool execution ──────────────────────────────────────────────────

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        bearer_token: str | None = None,
    ) -> dict[str, Any]:
        """Execute a tool on the MCP server with the user's Bearer token.

        Creates a short-lived connection with the user's auth for each call,
        ensuring the MCP server sees the real user identity.
        """
        logger.info("MCP tool call: %s(%s)", name, json.dumps(arguments)[:200])

        # Create a per-call connection with the user's Bearer token
        headers = config.mcp_headers(bearer_token)
        client_ctx = streamablehttp_client(config.MCP_SERVER_URL, headers=headers)
        streams = await client_ctx.__aenter__()
        try:
            session = ClientSession(streams[0], streams[1])
            await session.__aenter__()
            try:
                await session.initialize()
                result = await asyncio.wait_for(
                    session.call_tool(name, arguments),
                    timeout=config.MCP_CALL_TIMEOUT,
                )
            finally:
                await session.__aexit__(None, None, None)
        finally:
            await client_ctx.__aexit__(None, None, None)

        # Normalise result to serialisable dict
        content_parts = []
        if hasattr(result, "content") and result.content:
            for part in result.content:
                if hasattr(part, "text"):
                    content_parts.append({"type": "text", "text": part.text})
                elif hasattr(part, "data"):
                    content_parts.append({"type": "binary", "data": part.data})
                else:
                    content_parts.append({"type": "unknown", "value": str(part)})

        is_error = getattr(result, "isError", False)

        return {
            "content": content_parts,
            "is_error": is_error,
        }

    # ── Health check ────────────────────────────────────────────────────

    async def ping(self) -> bool:
        """Quick health check — try listing tools."""
        try:
            if not self._session:
                return False
            await asyncio.wait_for(
                self._session.list_tools(),
                timeout=5,
            )
            return True
        except Exception:
            return False


# Module-level singleton
mcp_client = MCPClient()
