"""L1/L2 Hierarchical Router — dispatches user requests to the right tool group.

L1 Dispatcher: lightweight, sees only tool group descriptions, picks the right group.
L2 Specialist: gets the actual tools for that group, executes the task.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


# ── Tool Group Definitions ──────────────────────────────────────────────

# Each group has a name, description (for L1 routing), and a list of tool
# name patterns. Tools are matched by prefix/keyword — not hardcoded names.

TOOL_GROUPS: list[dict[str, Any]] = [
    {
        "name": "project_management",
        "description": "Manage projects — list, create, update, delete projects. View project details, members, quotas, and resource counts.",
        "keywords": ["project", "pm_"],
    },
    {
        "name": "compute",
        "description": "Manage virtual machines and compute instances — list, create, start, stop, reboot, terminate VMs. View VM details, flavors, images.",
        "keywords": ["compute", "vm_", "instance_", "flavor", "image"],
    },
    {
        "name": "networking",
        "description": "Manage network resources — load balancers, firewalls, DNS, floating IPs, security groups, VPNs, subnets.",
        "keywords": ["lb", "lbaas", "network", "firewall", "dns", "floating", "security_group", "vpn", "subnet"],
    },
    {
        "name": "storage",
        "description": "Manage storage resources — NFS shares, SMB shares, volumes, snapshots, backups.",
        "keywords": ["storage", "nfs", "smb", "volume", "snapshot", "backup"],
    },
    {
        "name": "baremetal",
        "description": "Manage bare metal servers — list, provision, decommission bare metal machines. View requests and server details.",
        "keywords": ["baremetal", "bm_"],
    },
    {
        "name": "daas",
        "description": "Database as a Service — manage database instances, clusters, backups, restores.",
        "keywords": ["daas", "database", "db_"],
    },
    {
        "name": "monitoring",
        "description": "Metrics, monitoring, alerts — view resource metrics, set up alerts, check health status.",
        "keywords": ["metric", "monitor", "alert", "health"],
    },
    {
        "name": "access_management",
        "description": "User access and permissions — manage user roles, API keys, team memberships, LDAP lookups.",
        "keywords": ["user", "access", "role", "permission", "ldap", "key", "team"],
    },
    {
        "name": "general",
        "description": "General queries, tool discovery, help — list available tools, search for capabilities, general questions about the platform.",
        "keywords": ["list_internal_tools", "get_tool_schema", "help"],
    },
]


def classify_tools_to_groups(all_tools: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """Assign MCP tools to groups based on keyword matching.

    Returns a dict of group_name → list of tools in OpenAI function format.
    """
    groups: dict[str, list[dict[str, Any]]] = {g["name"]: [] for g in TOOL_GROUPS}

    for tool in all_tools:
        name = tool.get("function", {}).get("name", "").lower()
        desc = tool.get("function", {}).get("description", "").lower()
        target = _match_tool_to_group(name, desc)
        groups[target].append(tool)

    return groups


def _match_tool_to_group(name: str, desc: str) -> str:
    """Find the best matching group for a tool by keyword."""
    for group in TOOL_GROUPS:
        for keyword in group["keywords"]:
            if keyword in name or keyword in desc:
                return group["name"]
    return "general"


# ── L1 Dispatcher ───────────────────────────────────────────────────────

async def route_request(
    user_message: str,
    available_groups: dict[str, list[dict[str, Any]]],
    current_group: str | None = None,
) -> str:
    """Fast keyword-based routing — no LLM call.

    Matches user message keywords to tool group keywords.
    Falls back to current group for follow-ups, or 'general' for new sessions.
    """
    # Fast path: alias reference or follow-up → stay in current group
    if current_group and (_is_alias_reference(user_message) or _is_follow_up(user_message)):
        logger.info("Follow-up/alias detected, staying in '%s'", current_group)
        return current_group

    # Keyword match against group definitions
    msg_lower = user_message.lower()
    best_group = None
    best_score = 0

    for group in TOOL_GROUPS:
        score = 0
        for keyword in group["keywords"]:
            if keyword in msg_lower:
                score += 1
        # Also check group description words
        for word in group["description"].lower().split():
            if len(word) > 3 and word in msg_lower:
                score += 0.5
        if score > best_score:
            best_score = score
            best_group = group["name"]

    if best_group and best_score >= 1 and available_groups.get(best_group):
        logger.info("Routed to '%s' (score=%.1f)", best_group, best_score)
        return best_group

    # No strong match — stay in current group or fall back to general
    if current_group:
        logger.info("No keyword match, staying in '%s'", current_group)
        return current_group

    logger.info("No match, defaulting to 'general'")
    return "general"


# Follow-up detection patterns (avoids LLM call for obvious continuations)
_FOLLOW_UP_PATTERNS = [
    "show details", "tell me more", "which ones", "filter", "sort by",
    "how many", "count", "created by", "owned by", "in prod", "in stage",
    "in dev", "status", "delete", "remove", "stop", "start", "reboot",
    "what about", "and the", "also", "same for", "do the same",
]

_ALIAS_PATTERN = __import__("re").compile(r"\b(proj|vm|srv|lb|nfs|smb|db|bm|vol|snap|res)-\d+\b")


def _is_alias_reference(message: str) -> bool:
    """Check if the message references a shadow store alias like vm-2, proj-3."""
    return bool(_ALIAS_PATTERN.search(message.lower()))


def _is_follow_up(message: str) -> bool:
    """Check if the message is clearly a follow-up to the current topic."""
    msg_lower = message.lower().strip()
    return any(pattern in msg_lower for pattern in _FOLLOW_UP_PATTERNS)


def get_group_tools(
    group_name: str,
    tool_groups: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    """Get the tools for a specific group, always including 'general' tools."""
    tools = list(tool_groups.get(group_name, []))

    # Always include general/discovery tools so the agent can search if needed
    if group_name != "general":
        tools.extend(tool_groups.get("general", []))

    # Deduplicate by tool name
    seen = set()
    unique = []
    for t in tools:
        name = t.get("function", {}).get("name", "")
        if name not in seen:
            seen.add(name)
            unique.append(t)

    return unique
