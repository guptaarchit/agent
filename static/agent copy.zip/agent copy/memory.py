"""Pinecone-backed long-term memory — embed and recall past conversation context."""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from openai import AzureOpenAI

import config

logger = logging.getLogger(__name__)

_index = None
_embedding_client: AzureOpenAI | None = None


async def init_memory() -> None:
    """Initialise Pinecone index and Azure OpenAI embedding client."""
    global _index, _embedding_client

    if not config.PINECONE_API_KEY:
        logger.warning("PINECONE_API_KEY not set — memory disabled")
        return

    # Pinecone
    from pinecone import Pinecone, ServerlessSpec

    pc = Pinecone(api_key=config.PINECONE_API_KEY)

    # Check if index exists, create if not
    existing = [idx.name for idx in pc.list_indexes()]
    if config.PINECONE_INDEX not in existing:
        logger.info("Pinecone index '%s' not found — creating it...", config.PINECONE_INDEX)
        pc.create_index(
            name=config.PINECONE_INDEX,
            dimension=1536,  # text-embedding-3-small output dimension
            metric="cosine",
            spec=ServerlessSpec(cloud="aws", region="us-east-1"),
        )
        logger.info("Pinecone index created: %s", config.PINECONE_INDEX)

    _index = pc.Index(config.PINECONE_INDEX)
    logger.info("Pinecone index connected: %s", config.PINECONE_INDEX)

    # Azure OpenAI Embeddings — test the deployment exists before enabling
    if config.AZURE_OPENAI_API_KEY and config.AZURE_OPENAI_ENDPOINT:
        try:
            client = AzureOpenAI(
                api_key=config.AZURE_OPENAI_API_KEY,
                azure_endpoint=config.AZURE_OPENAI_EMBEDDING_ENDPOINT,
                api_version=config.AZURE_OPENAI_EMBEDDING_API_VERSION,
            )
            # Quick test to verify the deployment exists
            client.embeddings.create(
                model=config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
                input="test",
            )
            _embedding_client = client
            logger.info(
                "Azure OpenAI embeddings ready: %s",
                config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
            )
        except Exception as e:
            logger.warning(
                "Azure OpenAI embedding deployment '%s' not available (%s) — "
                "memory will run without embeddings (session history still works via Redis)",
                config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT, e,
            )
            _embedding_client = None
    else:
        logger.warning("Azure OpenAI credentials missing — embeddings disabled")


def _embed(text: str) -> list[float]:
    """Generate embedding vector via Azure OpenAI text-embedding-3-small."""
    if _embedding_client is None:
        raise RuntimeError("Embedding client not initialised")
    resp = _embedding_client.embeddings.create(
        model=config.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
        input=text[:8000],  # model input limit
    )
    return resp.data[0].embedding


def _is_available() -> bool:
    """Return True if both Pinecone and the embedding client are ready."""
    return _index is not None and _embedding_client is not None


# ── Store messages ──────────────────────────────────────────────────────


async def store_message(
    session_id: str,
    message_index: int,
    role: str,
    content: str,
    tool_name: str | None = None,
) -> None:
    """Embed and upsert a single message to Pinecone. Non-blocking."""
    if not _is_available():
        return

    try:
        vector_id = f"{session_id}_{message_index}"
        embedding = _embed(content[:2000])

        metadata = {
            "session_id": session_id,
            "role": role,
            "content": content[:5000],
            "content_preview": content[:200],
            "tool_name": tool_name or "",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "message_index": message_index,
        }

        _index.upsert(
            vectors=[(vector_id, embedding, metadata)],
            namespace=session_id,
        )
    except Exception as e:
        logger.warning("Failed to store message in Pinecone: %s", e)


# ── Recall ──────────────────────────────────────────────────────────────


async def recall(
    session_id: str,
    query: str,
    top_k: int | None = None,
) -> list[dict[str, Any]]:
    """Semantic search within a session."""
    if not _is_available():
        return []

    top_k = top_k or config.PINECONE_TOP_K

    try:
        embedding = _embed(query)
        results = _index.query(
            vector=embedding,
            top_k=top_k,
            namespace=session_id,
            include_metadata=True,
        )

        return [
            {
                "role": match.get("metadata", {}).get("role", "unknown"),
                "content": match.get("metadata", {}).get("content", ""),
                "tool_name": match.get("metadata", {}).get("tool_name", ""),
                "timestamp": match.get("metadata", {}).get("timestamp", ""),
                "score": match.get("score", 0),
            }
            for match in results.get("matches", [])
        ]
    except Exception as e:
        logger.warning("Pinecone recall failed: %s", e)
        return []


async def recall_cross_session(
    query: str,
    top_k: int | None = None,
) -> list[dict[str, Any]]:
    """Search across ALL sessions (future enhancement)."""
    if not _is_available():
        return []

    top_k = top_k or config.PINECONE_TOP_K

    try:
        embedding = _embed(query)
        results = _index.query(
            vector=embedding,
            top_k=top_k,
            include_metadata=True,
        )

        return [
            {
                "session_id": match.get("metadata", {}).get("session_id", ""),
                "role": match.get("metadata", {}).get("role", "unknown"),
                "content": match.get("metadata", {}).get("content", ""),
                "timestamp": match.get("metadata", {}).get("timestamp", ""),
                "score": match.get("score", 0),
            }
            for match in results.get("matches", [])
        ]
    except Exception as e:
        logger.warning("Pinecone cross-session recall failed: %s", e)
        return []


# ── Cleanup ─────────────────────────────────────────────────────────────


async def delete_session_memory(session_id: str) -> None:
    """Remove all vectors for a session from Pinecone."""
    if not _is_available():
        return
    try:
        _index.delete(delete_all=True, namespace=session_id)
        logger.info("Pinecone session memory deleted: %s", session_id)
    except Exception as e:
        logger.warning("Failed to delete Pinecone session memory: %s", e)
