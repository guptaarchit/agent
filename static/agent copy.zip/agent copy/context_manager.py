"""Context manager — sliding window + compaction + shadow store integration.

Tiered memory strategy:
1. Sliding window: only last N turns go to LLM (configurable)
2. Session state block: persistent context injected every turn
3. Shadow store aliases: referenced by ID, full data in Redis
4. Compaction: if still over budget, summarise oldest messages
5. Pinecone recall: for references to things outside the window
"""

from __future__ import annotations

import logging
from typing import Any

import tiktoken

import config
import llm_client

logger = logging.getLogger(__name__)

_encoder: tiktoken.Encoding | None = None

# Sliding window: max message pairs to keep in the LLM prompt
SLIDING_WINDOW_TURNS: int = int(config.CONVERSATION_HISTORY_LIMIT)  # from .env, default 12
MAX_SINGLE_MESSAGE_CHARS: int = 6_000


def _get_encoder() -> tiktoken.Encoding:
    """Lazily initialise and return the cl100k_base tiktoken encoder."""
    global _encoder
    if _encoder is None:
        _encoder = tiktoken.get_encoding("cl100k_base")
    return _encoder


def count_tokens(text: str) -> int:
    """Return the token count for a string using the cl100k_base encoding."""
    return len(_get_encoder().encode(text))


def count_messages_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate total token count across a list of chat messages."""
    total = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total += count_tokens(content) + 4
        elif isinstance(content, list):
            for part in content:
                total += count_tokens(str(part)) + 2
            total += 4
        else:
            total += count_tokens(str(content)) + 4
    return total


def _context_budget(model: str) -> int:
    """70% of model's context window."""
    if "gpt-4o" in model.lower():
        return int(128_000 * 0.7)
    if "gpt-4" in model.lower():
        return int(128_000 * 0.7)
    if "claude" in model.lower():
        return int(200_000 * 0.7)
    if "gemini" in model.lower():
        return int(1_000_000 * 0.7)
    return int(128_000 * 0.7)


# ── Main entry point ────────────────────────────────────────────────────


async def prepare_context(
    messages: list[dict[str, Any]],
    system_prompt: str,
    tools: list[dict[str, Any]],
    session_id: str,
    model: str | None = None,
) -> list[dict[str, Any]]:
    """Build the message list for the LLM, applying the tiered memory strategy.

    1. Apply sliding window (keep last N messages)
    2. Trim oversized individual messages
    3. Check token budget, compact if needed
    """
    model = model or config.DEFAULT_MODEL
    budget = _context_budget(model)

    # Step 1: Sliding window — only keep recent turns
    windowed = _apply_sliding_window(messages)

    # Step 2: Trim any single bloated message
    windowed = _trim_oversized_messages(windowed)

    # Step 3: Check if we're within budget
    system_tokens = count_tokens(system_prompt)
    tools_tokens = count_tokens(str(tools))
    fixed_overhead = system_tokens + tools_tokens
    available = budget - fixed_overhead

    if available <= 0:
        logger.warning("System prompt + tools alone exceed context budget")
        return windowed[-4:]

    msg_tokens = count_messages_tokens(windowed)

    if msg_tokens <= available:
        return windowed

    # Step 4: Compaction — summarise oldest messages in the window
    logger.info(
        "Context compaction triggered: %d tokens > %d budget (session=%s)",
        msg_tokens, available, session_id,
    )
    return await _compact(windowed, available)


# ── Sliding Window ──────────────────────────────────────────────────────


def _apply_sliding_window(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Keep only the last N messages. Earlier messages are dropped.

    The shadow store and session state handle continuity —
    the LLM doesn't need the full history.
    """
    if len(messages) <= SLIDING_WINDOW_TURNS:
        return messages
    logger.debug(
        "Sliding window: %d messages → keeping last %d",
        len(messages), SLIDING_WINDOW_TURNS,
    )
    return messages[-SLIDING_WINDOW_TURNS:]


# ── Trim Oversized Messages ────────────────────────────────────────────


def _trim_oversized_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Truncate any individual message that's excessively large."""
    trimmed = []
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str) and len(content) > MAX_SINGLE_MESSAGE_CHARS:
            msg = dict(msg)
            msg["content"] = (
                content[:MAX_SINGLE_MESSAGE_CHARS]
                + f"\n[Trimmed from {len(content):,} chars. Full data in shadow store.]"
            )
        trimmed.append(msg)
    return trimmed


# ── Compaction ──────────────────────────────────────────────────────────


async def _compact(
    messages: list[dict[str, Any]],
    available_tokens: int,
) -> list[dict[str, Any]]:
    """Summarise old messages within the window, keep recent ones verbatim."""
    recent_count = min(6, len(messages))
    recent = messages[-recent_count:]
    old = messages[:-recent_count]

    if not old:
        return recent

    recent_tokens = count_messages_tokens(recent)
    summary_budget = available_tokens - recent_tokens - 500

    if summary_budget <= 0:
        return recent[-4:]

    summary_text = await _summarise_messages(old, summary_budget)

    summary_message = {
        "role": "system",
        "content": f"[Earlier conversation summary]\n{summary_text}",
    }

    return [summary_message] + recent


async def _summarise_messages(
    messages: list[dict[str, Any]], max_tokens: int
) -> str:
    """Call LLM to summarise a batch of messages."""
    lines = []
    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        if isinstance(content, list):
            content = str(content)
        lines.append(f"[{role}]: {content[:300]}")

    conversation_text = "\n".join(lines)

    response = await llm_client.chat_complete(
        messages=[
            {
                "role": "system",
                "content": (
                    "Summarise this conversation concisely. Preserve:\n"
                    "- Resource IDs, names, alias references (proj-1, vm-2)\n"
                    "- Decisions made and actions taken\n"
                    "- User's current focus/intent\n"
                    "Be factual. 3-5 bullet points max."
                ),
            },
            {"role": "user", "content": conversation_text},
        ],
        max_tokens=min(max_tokens, 500),
    )

    return response.get("content", "Summary unavailable.")

