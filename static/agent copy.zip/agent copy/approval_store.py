"""Redis-backed approval store for pending destructive actions and plans."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

import redis.asyncio as aioredis

import config
from session_store import _r

logger = logging.getLogger(__name__)


def _approval_key(session_id: str, action_id: str) -> str:
    """Build the Redis key for a specific pending approval."""
    return f"approval:{session_id}:{action_id}"


def _session_approvals_pattern(session_id: str) -> str:
    """Return a Redis SCAN glob matching all approvals for a session."""
    return f"approval:{session_id}:*"


# ── Create pending actions ──────────────────────────────────────────────


async def create_pending_action(
    session_id: str,
    tool: str,
    arguments: dict[str, Any],
    description: str,
    agent_state: dict[str, Any],
) -> str:
    """Store a single pending destructive action. Returns action_id."""
    action_id = f"act_{uuid4().hex[:12]}"
    r = _r()
    data = {
        "type": "action",
        "action_id": action_id,
        "session_id": session_id,
        "tool": tool,
        "arguments": json.dumps(arguments),
        "description": description,
        "agent_state": json.dumps(agent_state),
        "status": "pending",
        "result": "",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    key = _approval_key(session_id, action_id)
    await r.hset(key, mapping=data)
    await r.expire(key, config.APPROVAL_TTL)
    logger.info("Pending action created: %s/%s tool=%s", session_id, action_id, tool)
    return action_id


async def create_pending_plan(
    session_id: str,
    steps: list[dict[str, Any]],
    summary: str,
    agent_state: dict[str, Any],
) -> str:
    """Store a pending plan. Returns plan_id."""
    plan_id = f"plan_{uuid4().hex[:12]}"
    r = _r()
    data = {
        "type": "plan",
        "action_id": plan_id,
        "session_id": session_id,
        "tool": "",
        "arguments": json.dumps(steps),
        "description": summary,
        "agent_state": json.dumps(agent_state),
        "status": "pending",
        "result": "",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    key = _approval_key(session_id, plan_id)
    await r.hset(key, mapping=data)
    await r.expire(key, config.APPROVAL_TTL)
    logger.info("Pending plan created: %s/%s", session_id, plan_id)
    return plan_id


# ── Retrieve ────────────────────────────────────────────────────────────


async def get_pending(session_id: str, action_id: str) -> dict[str, Any] | None:
    """Retrieve a pending action/plan by ID, parsing JSON fields."""
    r = _r()
    data = await r.hgetall(_approval_key(session_id, action_id))
    if not data:
        return None
    # Parse JSON fields
    for field in ("arguments", "agent_state"):
        if field in data and data[field]:
            try:
                data[field] = json.loads(data[field])
            except (json.JSONDecodeError, TypeError):
                pass
    if "result" in data and data["result"]:
        try:
            data["result"] = json.loads(data["result"])
        except (json.JSONDecodeError, TypeError):
            pass
    return data


# ── Approve / Deny (idempotent) ─────────────────────────────────────────


async def approve(session_id: str, action_id: str) -> dict[str, Any] | None:
    """Mark as executing. Returns pending data or None if not found/already handled.

    Idempotent: if already completed, returns the cached result.
    """
    r = _r()
    key = _approval_key(session_id, action_id)
    data = await get_pending(session_id, action_id)
    if not data:
        return None

    status = data.get("status", "")

    if status == "completed":
        # Already executed — return cached result (idempotent)
        return data

    if status == "executing":
        # Another request is already processing this
        return {"status": "executing", "action_id": action_id}

    if status == "denied":
        return {"status": "denied", "action_id": action_id}

    # Transition: pending → executing
    await r.hset(key, "status", "executing")
    data["status"] = "executing"
    return data


async def mark_completed(
    session_id: str, action_id: str, result: Any
) -> None:
    """Mark action as completed and cache the result."""
    r = _r()
    key = _approval_key(session_id, action_id)
    await r.hset(key, mapping={
        "status": "completed",
        "result": json.dumps(result) if not isinstance(result, str) else result,
    })
    # Keep around for idempotency checks, but shorter TTL
    await r.expire(key, 300)


async def deny(session_id: str, action_id: str, reason: str = "") -> dict[str, Any] | None:
    """Mark as denied. Returns pending data or None."""
    r = _r()
    key = _approval_key(session_id, action_id)
    data = await get_pending(session_id, action_id)
    if not data:
        return None

    status = data.get("status", "")
    if status in ("completed", "denied"):
        return data

    await r.hset(key, mapping={"status": "denied", "result": reason})
    await r.expire(key, 60)
    data["status"] = "denied"
    logger.info("Action denied: %s/%s reason=%s", session_id, action_id, reason[:100])
    return data


# ── Cleanup ─────────────────────────────────────────────────────────────


async def clear_session_approvals(session_id: str) -> int:
    """Delete all pending approvals for a session."""
    r = _r()
    cursor = 0
    deleted = 0
    while True:
        cursor, keys = await r.scan(
            cursor, match=_session_approvals_pattern(session_id), count=100
        )
        if keys:
            deleted += await r.delete(*keys)
        if cursor == 0:
            break
    return deleted
