"""Redis-based sliding window rate limiter."""

from __future__ import annotations

import time
import logging

import config
from session_store import _r

logger = logging.getLogger(__name__)


async def check_rate_limit(
    user_id: str,
    endpoint: str,
    limit: int | None = None,
    window: int = 60,
) -> tuple[bool, int]:
    """Check rate limit for a user on an endpoint.

    Returns (allowed, remaining_requests).
    """
    if not limit:
        # Default limits by endpoint
        limits = {
            "chat": config.RATE_LIMIT_CHAT,
            "approve": config.RATE_LIMIT_APPROVE,
            "history": config.RATE_LIMIT_HISTORY,
        }
        limit = limits.get(endpoint, 60)

    key = f"ratelimit:{user_id}:{endpoint}"
    now = time.time()
    window_start = now - window

    r = _r()
    pipe = r.pipeline()
    # Remove old entries outside window
    pipe.zremrangebyscore(key, 0, window_start)
    # Add current request
    pipe.zadd(key, {str(now): now})
    # Count requests in window
    pipe.zcard(key)
    # Set expiry
    pipe.expire(key, window)
    results = await pipe.execute()

    current_count = results[2]
    remaining = max(0, limit - current_count)
    allowed = current_count <= limit

    if not allowed:
        logger.warning("Rate limit exceeded: user=%s endpoint=%s count=%d limit=%d", user_id, endpoint, current_count, limit)

    return allowed, remaining
