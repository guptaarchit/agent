"""Immutable audit log — append-only structured event logging."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

import config

logger = logging.getLogger(__name__)

_audit_file = None


class AuditEventType(StrEnum):
    MESSAGE_RECEIVED = "message_received"
    LLM_CALL = "llm_call"
    TOOL_EXECUTED = "tool_executed"
    TOOL_BLOCKED = "tool_blocked"
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_DENIED = "approval_denied"
    PLAN_GENERATED = "plan_generated"
    PLAN_APPROVED = "plan_approved"
    PLAN_DENIED = "plan_denied"
    INJECTION_DETECTED = "injection_detected"
    PII_REDACTED = "pii_redacted"
    SESSION_CREATED = "session_created"
    SESSION_EXPIRED = "session_expired"
    SESSION_DELETED = "session_deleted"
    EXECUTION_LIMIT = "execution_limit"
    COST_LIMIT = "cost_limit"
    RATE_LIMIT = "rate_limit"
    CIRCUIT_BREAKER = "circuit_breaker"
    ERROR = "error"


def _get_audit_file():
    """Lazily open the append-only JSONL audit log file."""
    global _audit_file
    if _audit_file is None:
        log_dir = os.path.join(config.FILE_STORE_DIR, "..", "audit_logs")
        os.makedirs(log_dir, exist_ok=True)
        path = os.path.join(log_dir, "audit.jsonl")
        _audit_file = open(path, "a")
        logger.info("Audit log initialised: %s", path)
    return _audit_file


def log_event(
    event_type: AuditEventType | str,
    *,
    session_id: str = "",
    user_id: str = "",
    correlation_id: str = "",
    data: dict[str, Any] | None = None,
) -> None:
    """Append an audit event. Never raises — failures are logged but swallowed."""
    try:
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event": str(event_type),
            "session_id": session_id,
            "user_id": user_id,
            "correlation_id": correlation_id,
            "data": data or {},
        }

        f = _get_audit_file()
        f.write(json.dumps(entry, default=str) + "\n")
        f.flush()

    except Exception as e:
        logger.error("Failed to write audit log: %s", e)
