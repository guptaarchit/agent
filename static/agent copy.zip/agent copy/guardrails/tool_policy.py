"""Execution safety — tool allowlist, argument validation, scope, limits."""

from __future__ import annotations

import logging
from typing import Any

import jsonschema

import config

logger = logging.getLogger(__name__)


def is_tool_allowed(tool_name: str) -> bool:
    """Check if a tool is allowed by policy."""
    if tool_name in config.TOOL_BLOCKLIST:
        return False
    if config.TOOL_ALLOWLIST is not None:
        return tool_name in config.TOOL_ALLOWLIST
    return True


def is_destructive(tool_name: str) -> bool:
    """Check if a tool name matches destructive patterns."""
    return config.is_destructive_tool(tool_name)


def validate_arguments(
    tool_name: str,
    arguments: dict[str, Any],
    schema: dict[str, Any],
) -> tuple[bool, str]:
    """Validate tool arguments against JSON schema. Returns (valid, error_message)."""
    # Cap string argument lengths
    for key, value in arguments.items():
        if isinstance(value, str) and len(value) > 1000:
            return False, f"Argument '{key}' exceeds max length (1000 chars)"

    if not schema:
        return True, ""

    try:
        jsonschema.validate(instance=arguments, schema=schema)
        return True, ""
    except jsonschema.ValidationError as e:
        return False, f"Argument validation failed: {e.message}"
    except jsonschema.SchemaError:
        # Bad schema from MCP — allow the call but warn
        logger.warning("Invalid JSON schema for tool %s", tool_name)
        return True, ""


def apply_scope(arguments: dict[str, Any]) -> dict[str, Any]:
    """Inject scope restrictions into tool arguments."""
    if not config.SCOPE_RESTRICTIONS:
        return arguments
    merged = dict(arguments)
    for key, value in config.SCOPE_RESTRICTIONS.items():
        merged[key] = value  # scope always overrides user-provided values
    return merged


async def check_limits(
    session_id: str,
    tool_call_count: int,
    destructive_action_count: int,
    is_destructive_call: bool = False,
) -> tuple[bool, str]:
    """Check per-session execution limits. Returns (allowed, reason)."""
    if tool_call_count >= config.MAX_TOOL_CALLS_PER_SESSION:
        return False, f"Session tool call limit reached ({config.MAX_TOOL_CALLS_PER_SESSION})"

    if is_destructive_call and destructive_action_count >= config.MAX_DESTRUCTIVE_ACTIONS_PER_SESSION:
        return False, f"Session destructive action limit reached ({config.MAX_DESTRUCTIVE_ACTIONS_PER_SESSION})"

    return True, ""


def filter_tools(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Remove non-allowed tools from the list before passing to LLM."""
    filtered = []
    for tool in tools:
        # Extract tool name from OpenAI function-calling format
        name = tool.get("function", {}).get("name", "")
        if is_tool_allowed(name):
            filtered.append(tool)
        else:
            logger.debug("Tool filtered out by policy: %s", name)
    return filtered
