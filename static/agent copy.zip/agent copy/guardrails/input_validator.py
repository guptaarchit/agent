"""Input safety — prompt injection detection, content filtering."""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# Known injection patterns
_INJECTION_PATTERNS: list[re.Pattern] = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"ignore\s+(all\s+)?previous\s+instructions",
        r"ignore\s+(all\s+)?prior\s+instructions",
        r"disregard\s+(all\s+)?previous",
        r"you\s+are\s+now\s+a",
        r"new\s+system\s+prompt",
        r"override\s+system",
        r"forget\s+(all\s+)?your\s+instructions",
        r"SYSTEM\s*:",
        r"ADMIN\s*:",
        r"OVERRIDE\s*:",
        r"<\s*system\s*>",
        r"<\s*/?\s*instructions?\s*>",
        r"\]\s*\}\s*system",
    ]
]


@dataclass
class ValidationResult:
    valid: bool = True
    warnings: list[str] = field(default_factory=list)
    sanitised_message: str = ""
    blocked: bool = False
    block_reason: str = ""


def validate_message(message: str) -> ValidationResult:
    """Validate a user message for content safety. Returns ValidationResult."""
    result = ValidationResult(sanitised_message=message)

    # Empty
    if not message or not message.strip():
        result.valid = False
        result.blocked = True
        result.block_reason = "Message is empty"
        return result

    # Oversized
    if len(message) > 10_000:
        result.valid = False
        result.blocked = True
        result.block_reason = f"Message too long: {len(message)} chars (max 10,000)"
        return result

    # Injection scan
    injection_result = scan_for_injection(message)
    if injection_result.warnings:
        result.warnings.extend(injection_result.warnings)
        # Don't block — just warn. The system prompt hardening handles the rest.

    return result


def scan_for_injection(text: str) -> ValidationResult:
    """Scan text for known prompt injection patterns."""
    result = ValidationResult(sanitised_message=text)

    for pattern in _INJECTION_PATTERNS:
        if pattern.search(text):
            result.warnings.append(f"Possible injection pattern detected: {pattern.pattern[:50]}")
            logger.warning(
                "Injection pattern detected: %s in text: %s",
                pattern.pattern[:50],
                text[:200],
            )

    return result


def sanitise_tool_result(text: str) -> str:
    """Strip injection attempts from MCP tool results before feeding to LLM."""
    # Remove anything that looks like it's trying to act as a system message
    sanitised = text
    for pattern in _INJECTION_PATTERNS:
        sanitised = pattern.sub("[REDACTED]", sanitised)
    return sanitised
