"""Output safety — PII/secret redaction, hallucination check, size limits."""

from __future__ import annotations

import re
import logging

import config

logger = logging.getLogger(__name__)

# Secret patterns: (name, regex, replacement)
_SECRET_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    ("AWS Access Key", re.compile(r"AKIA[0-9A-Z]{16}"), "AKIA****"),
    ("OpenAI API Key", re.compile(r"sk-[a-zA-Z0-9]{20,}"), "sk-****"),
    ("Bearer Token", re.compile(r"Bearer\s+eyJ[a-zA-Z0-9._-]{20,}"), "Bearer ****"),
    ("Basic Auth", re.compile(r"Basic\s+[A-Za-z0-9+/=]{20,}"), "Basic ****"),
    ("Generic API Key", re.compile(r"(?i)(api[_-]?key|token|secret|password)\s*[=:]\s*\S{8,}"), r"\1=****"),
    ("Connection String", re.compile(r"(?i)(postgresql|mysql|mongodb|redis)://[^\s]+"), r"\1://****"),
    ("Private Key", re.compile(r"-----BEGIN\s+(RSA\s+)?PRIVATE KEY-----"), "[PRIVATE KEY REDACTED]"),
]

# PII patterns
_PII_PATTERNS: list[tuple[str, re.Pattern, str]] = [
    ("Email", re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"), "****@****.***"),
    ("Internal IP", re.compile(r"\b(10|172\.(1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}\b"), "***.***.***"),
]


def redact_secrets(text: str) -> str:
    """Scan and redact secrets and PII from text."""
    result = text
    for name, pattern, replacement in _SECRET_PATTERNS:
        if pattern.search(result):
            result = pattern.sub(replacement, result)
            logger.info("Redacted %s from output", name)
    for name, pattern, replacement in _PII_PATTERNS:
        if pattern.search(result):
            result = pattern.sub(replacement, result)
    return result


def truncate_tool_result(result: str, max_chars: int | None = None) -> str:
    """Truncate oversized tool results before feeding back to LLM."""
    max_chars = max_chars or config.MAX_TOOL_RESULT_CHARS
    if len(result) <= max_chars:
        return result
    truncated = result[:max_chars]
    lines_total = result.count("\n")
    lines_kept = truncated.count("\n")
    return (
        f"{truncated}\n\n"
        f"[Truncated: showing ~{lines_kept} of ~{lines_total} lines, "
        f"{max_chars:,} of {len(result):,} chars. "
        f"Ask for specific filters to narrow down.]"
    )


def chunk_result(result: str, chunk_size: int = 4000) -> list[dict]:
    """Split a large result into chunks for SSE streaming to UI."""
    import json

    try:
        data = json.loads(result)
        if isinstance(data, list):
            item_chunks = [data[i:i + 20] for i in range(0, len(data), 20)]
            return [
                {"chunk_index": i, "total_chunks": len(item_chunks), "data": c}
                for i, c in enumerate(item_chunks)
            ]
    except (json.JSONDecodeError, TypeError):
        pass

    text_chunks = [result[i:i + chunk_size] for i in range(0, len(result), chunk_size)]
    return [
        {"chunk_index": i, "total_chunks": len(text_chunks), "data": c}
        for i, c in enumerate(text_chunks)
    ]


# Action verbs that suggest the agent did something
_ACTION_VERBS = re.compile(
    r"\b(terminated|deleted|removed|destroyed|stopped|created|updated|modified|purged|dropped|reset)\b",
    re.IGNORECASE,
)


def check_hallucination(
    response_text: str,
    tool_calls_made: list[str],
) -> list[str]:
    """Cross-check: did the agent claim actions that weren't actually taken?

    Returns list of warning messages (empty = no hallucinations detected).
    """
    warnings = []
    matches = _ACTION_VERBS.findall(response_text)
    if not matches:
        return warnings

    # If agent claims actions but no tool calls were made at all
    if matches and not tool_calls_made:
        warnings.append(
            f"Agent claims actions ({', '.join(set(matches))}) but no tool calls were made in this turn."
        )

    return warnings
