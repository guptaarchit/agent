"""Cost guardrails — track spend per session/user, enforce budgets."""

from __future__ import annotations

import logging
from typing import Any

import config
from session_store import _r

logger = logging.getLogger(__name__)


def _session_cost_key(session_id: str) -> str:
    """Build the Redis key for tracking a session's accumulated cost."""
    return f"cost:session:{session_id}"


def _user_day_cost_key(user_id: str) -> str:
    """Build the Redis key for tracking a user's daily cost."""
    from datetime import datetime, timezone
    day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return f"cost:user:{user_id}:{day}"


async def track_usage(
    session_id: str,
    user_id: str,
    input_tokens: int,
    output_tokens: int,
    model: str,
) -> None:
    """Record token usage and estimated cost."""
    # Rough cost estimates per million tokens
    cost_map = {
        "anthropic/claude-opus-4-6": (5.0, 25.0),
        "anthropic/claude-sonnet-4-6": (3.0, 15.0),
        "gpt-4o": (2.5, 10.0),
        "gpt-4.1": (2.0, 8.0),
    }
    input_rate, output_rate = cost_map.get(model, (3.0, 15.0))  # default to mid-range
    cost = (input_tokens * input_rate + output_tokens * output_rate) / 1_000_000

    r = _r()
    # Session cost
    await r.incrbyfloat(_session_cost_key(session_id), cost)
    await r.expire(_session_cost_key(session_id), config.SESSION_TTL)

    # User daily cost
    user_key = _user_day_cost_key(user_id)
    await r.incrbyfloat(user_key, cost)
    await r.expire(user_key, 86400)  # 24 hours


async def check_budget(
    session_id: str,
    user_id: str,
) -> tuple[bool, str, dict[str, float]]:
    """Check if session/user is within budget. Returns (allowed, reason, details)."""
    r = _r()

    session_spend = float(await r.get(_session_cost_key(session_id)) or 0)
    user_spend = float(await r.get(_user_day_cost_key(user_id)) or 0)

    details = {
        "session_spend": round(session_spend, 4),
        "session_limit": config.MAX_SPEND_PER_SESSION,
        "user_day_spend": round(user_spend, 4),
        "user_day_limit": config.MAX_SPEND_PER_USER_DAY,
    }

    if session_spend >= config.MAX_SPEND_PER_SESSION:
        return False, f"Session budget exceeded (${session_spend:.2f} / ${config.MAX_SPEND_PER_SESSION:.2f})", details

    if user_spend >= config.MAX_SPEND_PER_USER_DAY:
        return False, f"Daily user budget exceeded (${user_spend:.2f} / ${config.MAX_SPEND_PER_USER_DAY:.2f})", details

    return True, "", details
