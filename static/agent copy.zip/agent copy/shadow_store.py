"""Shadow Data Store — stores large MCP results in Redis with alias indexing.

Instead of stuffing 1000s of JSON objects into the LLM context:
1. Store raw data in Redis
2. Assign short alias IDs (e.g. vm-1, vm-2, proj-3)
3. Give LLM only a summary + alias mapping
4. User can say "reboot vm-2" and we resolve the alias to the real resource
"""

from __future__ import annotations

import json
import logging
from typing import Any

import config
from session_store import _r

logger = logging.getLogger(__name__)

# Alias prefix by resource type
_ALIAS_PREFIXES = {
    "project": "proj",
    "vm": "vm",
    "instance": "vm",
    "server": "srv",
    "loadbalancer": "lb",
    "nfs": "nfs",
    "smb": "smb",
    "database": "db",
    "baremetal": "bm",
    "volume": "vol",
    "snapshot": "snap",
    "default": "res",
}


def _alias_key(session_id: str) -> str:
    return f"aliases:{session_id}"


def _data_key(session_id: str, tool_name: str) -> str:
    return f"shadow:{session_id}:{tool_name}"


def _detect_resource_type(tool_name: str) -> str:
    """Guess the resource type from the tool name for alias prefixing."""
    tool_lower = tool_name.lower()
    for keyword, prefix in _ALIAS_PREFIXES.items():
        if keyword in tool_lower:
            return prefix
    return _ALIAS_PREFIXES["default"]


# ── Store & Index ───────────────────────────────────────────────────────


async def store_result(
    session_id: str,
    tool_name: str,
    data: list[dict[str, Any]],
    id_field: str | None = None,
    name_field: str | None = None,
) -> dict[str, Any]:
    """Store a tool result and create alias index.

    Returns a summary dict for the LLM with aliases and key stats.
    """
    r = _r()
    prefix = _detect_resource_type(tool_name)

    # Auto-detect ID and name fields
    if data and isinstance(data[0], dict):
        fields = list(data[0].keys())
        if not id_field:
            id_field = _find_field(fields, ["id", "ID", "Id", "resource_id"])
        if not name_field:
            name_field = _find_field(fields, ["name", "Name", "hostname", "title"])

    # Build alias mapping
    aliases: dict[str, dict[str, Any]] = {}
    summary_rows: list[dict[str, str]] = []

    for i, item in enumerate(data):
        alias = f"{prefix}-{i + 1}"
        real_id = str(item.get(id_field, i)) if id_field else str(i)
        display_name = str(item.get(name_field, alias)) if name_field else alias

        aliases[alias] = {
            "real_id": real_id,
            "name": display_name,
            "data": item,
        }

        # Build a compact summary row for the LLM
        row = {"alias": alias, "name": display_name}
        # Add a few key fields for context
        for f in _pick_summary_fields(item, id_field, name_field):
            row[f] = str(item.get(f, ""))[:60]
        summary_rows.append(row)

    # Store in Redis
    # Full data (for resolving aliases later)
    await r.set(
        _data_key(session_id, tool_name),
        json.dumps(data, default=str),
        ex=config.SESSION_TTL,
    )

    # Alias map (for quick lookup)
    alias_data = await r.get(_alias_key(session_id))
    all_aliases = json.loads(alias_data) if alias_data else {}
    all_aliases.update(aliases)
    await r.set(
        _alias_key(session_id),
        json.dumps(all_aliases, default=str),
        ex=config.SESSION_TTL,
    )

    logger.info(
        "Shadow store: %d items from %s, aliases %s-1 to %s-%d",
        len(data), tool_name, prefix, prefix, len(data),
    )

    return {
        "total": len(data),
        "aliases": summary_rows,
        "tool": tool_name,
    }


# ── Resolve Aliases ─────────────────────────────────────────────────────


async def resolve_alias(session_id: str, alias: str) -> dict[str, Any] | None:
    """Resolve a chat alias (e.g. 'vm-2') to the full resource data."""
    r = _r()
    raw = await r.get(_alias_key(session_id))
    if not raw:
        return None
    all_aliases = json.loads(raw)
    return all_aliases.get(alias)


# ── Build LLM Summary ──────────────────────────────────────────────────


def build_llm_summary(store_result: dict[str, Any]) -> str:
    """Create a compact text summary for the LLM context.

    Includes alias IDs so the LLM can reference them, and the user
    can say 'show details for proj-3' in follow-ups.
    """
    total = store_result["total"]
    tool = store_result["tool"]
    aliases = store_result["aliases"]

    lines = [
        f"[{tool}: {total} results. Full data displayed to user as table.]",
        f"[User can reference items by alias ID (e.g. '{aliases[0]['alias']}')]",
        "---",
    ]

    for row in aliases:
        parts = [f"{k}={v}" for k, v in row.items()]
        lines.append(" | ".join(parts))

    lines.append("---")
    lines.append("[Refer to items by alias (e.g. proj-1, vm-3). "
                 "Do NOT list all items. Answer the user's question concisely.]")

    result = "\n".join(lines)
    if len(result) > 10000:
        result = result[:10000] + f"\n[...truncated, {total} items total]"
    return result


# ── Helpers ─────────────────────────────────────────────────────────────


def _find_field(fields: list[str], candidates: list[str]) -> str | None:
    """Find the first matching field name from candidates."""
    fields_lower = {f.lower(): f for f in fields}
    for c in candidates:
        if c.lower() in fields_lower:
            return fields_lower[c.lower()]
    return None


def _pick_summary_fields(
    item: dict[str, Any],
    exclude_id: str | None,
    exclude_name: str | None,
) -> list[str]:
    """Pick 3-4 informative fields for the summary row."""
    priority = ["status", "Status", "landscape", "Landscape", "type", "Type",
                "created", "Created", "CreatedBy", "CreatedByUser", "email",
                "region", "Region", "state", "State"]
    selected = []
    for f in priority:
        if f in item and f != exclude_id and f != exclude_name:
            selected.append(f)
            if len(selected) >= 4:
                break
    return selected
