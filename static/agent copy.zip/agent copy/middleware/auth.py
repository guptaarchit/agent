"""JWT / API key authentication middleware."""

from __future__ import annotations

import logging
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

from jose import JWTError, jwt

import config

logger = logging.getLogger(__name__)

_bearer_scheme = HTTPBearer(auto_error=False)
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


@dataclass
class AuthContext:
    """Holds the authenticated user identity and the raw Bearer token for forwarding."""
    user_id: str
    bearer_token: str | None = None  # raw token to forward to MCP server


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    api_key: str | None = Security(_api_key_header),
) -> AuthContext:
    """Extract and validate user identity from JWT or API key.

    Returns AuthContext with user_id and the raw bearer token for MCP forwarding.
    """
    # Try Bearer token (ITC token / JWT)
    if credentials and credentials.credentials:
        try:
            payload = jwt.decode(
                credentials.credentials,
                config.ITC_TOKEN_SECRET,
                algorithms=[config.JWT_ALGORITHM],
                options={"verify_exp": False, "verify_aud": False, "verify_iss": False},
            )
            # Extract user ID — check nested "user" object first (ITC token format),
            # then fall back to standard JWT claims
            user_obj = payload.get("user", {})
            user_id = (
                user_obj.get("id")
                or user_obj.get("email")
                or payload.get("sub")
                or payload.get("user_id")
                or payload.get("email")
                or payload.get("preferred_username")
                or "unknown"
            )
            return AuthContext(
                user_id=user_id,
                bearer_token=credentials.credentials,  # raw token forwarded to MCP
            )
        except JWTError as e:
            logger.warning("ITC token validation failed: %s", e)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired Bearer token",
            ) from e

    # Try API key
    if api_key and config.API_KEY and api_key == config.API_KEY:
        return AuthContext(user_id="service-account", bearer_token=None)

    # No valid credentials
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required. Provide a JWT Bearer token or X-API-Key header.",
    )
