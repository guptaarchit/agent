"""Circuit breaker for MCP server calls."""

from __future__ import annotations

import logging
import time
from enum import StrEnum

import config

logger = logging.getLogger(__name__)


class CircuitState(StrEnum):
    CLOSED = "closed"        # normal — calls go through
    OPEN = "open"            # failing — calls blocked
    HALF_OPEN = "half_open"  # testing — one call allowed


class CircuitBreaker:
    """Wraps MCP calls. Opens after N consecutive failures, auto-recovers."""

    def __init__(
        self,
        threshold: int | None = None,
        recovery_seconds: int | None = None,
    ):
        self.threshold = threshold or config.CIRCUIT_BREAKER_THRESHOLD
        self.recovery_seconds = recovery_seconds or config.CIRCUIT_BREAKER_RECOVERY
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: float = 0
        self._last_state_change: float = time.time()

    @property
    def state(self) -> CircuitState:
        if self._state == CircuitState.OPEN:
            # Check if recovery period has elapsed → half-open
            if time.time() - self._last_failure_time >= self.recovery_seconds:
                self._state = CircuitState.HALF_OPEN
                self._last_state_change = time.time()
                logger.info("Circuit breaker → HALF_OPEN (testing recovery)")
        return self._state

    def allow_request(self) -> bool:
        """Should we allow this MCP call?"""
        state = self.state
        if state == CircuitState.CLOSED:
            return True
        if state == CircuitState.HALF_OPEN:
            return True  # allow one test call
        return False  # OPEN — block

    def record_success(self) -> None:
        """Call succeeded — reset if half-open, otherwise stay closed."""
        if self._state in (CircuitState.HALF_OPEN, CircuitState.OPEN):
            logger.info("Circuit breaker → CLOSED (recovered)")
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_state_change = time.time()

    def record_failure(self) -> None:
        """Call failed — increment counter, maybe open circuit."""
        self._failure_count += 1
        self._last_failure_time = time.time()

        if self._state == CircuitState.HALF_OPEN:
            # Test call failed — back to open
            self._state = CircuitState.OPEN
            self._last_state_change = time.time()
            logger.warning("Circuit breaker → OPEN (half-open test failed)")
            return

        if self._failure_count >= self.threshold:
            self._state = CircuitState.OPEN
            self._last_state_change = time.time()
            logger.warning(
                "Circuit breaker → OPEN after %d consecutive failures",
                self._failure_count,
            )

    def status(self) -> dict:
        """Return a dict describing the current circuit breaker state."""
        return {
            "state": self.state,
            "failure_count": self._failure_count,
            "threshold": self.threshold,
            "recovery_seconds": self.recovery_seconds,
            "last_state_change": self._last_state_change,
        }


# Module-level singleton
mcp_circuit_breaker = CircuitBreaker()
